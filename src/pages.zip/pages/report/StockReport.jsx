import { useState } from 'react';
import Select from 'react-select';
import TableSortIcon from '../../components/TableSortIcon';

const productTypeOptions = [
    { value: 'compressor', label: 'Compressor' },
    { value: 'spares',     label: 'Spares'     },
    { value: 'service',    label: 'Service'    },
    { value: 'others',     label: 'Others'     },
];

const DUMMY_DATA = [
    { id: 1, productType: 'Compressor', productName: 'CTSD 60 - Compressor Air Filter CT00000483', totalQty: 20, availableQty: 15, lastUpdated: '10-06-2026' },
    { id: 2, productType: 'Spares',     productName: 'CTSD 60 - Compressor Spares Oil Filter',       totalQty: 50, availableQty: 42, lastUpdated: '09-06-2026' },
    { id: 3, productType: 'Spares',     productName: 'CTSD 60 - Compressor Spares Belt Set',         totalQty: 30, availableQty: 28, lastUpdated: '08-06-2026' },
    { id: 4, productType: 'Compressor', productName: 'CTSD 60 - Separator Element CT00000501',       totalQty: 10, availableQty: 7,  lastUpdated: '07-06-2026' },
    { id: 5, productType: 'Service',    productName: 'Annual Maintenance Service Pack - CTSD Series', totalQty: 5,  availableQty: 5,  lastUpdated: '05-06-2026' },
];

const StockReport = () => {
    const [productName, setProductName] = useState('');
    const [productType, setProductType] = useState(null);

    const handleReset = () => {
        setProductName('');
        setProductType(null);
    };

    return (
        <section className="content">
            <div className="container-fluid">
                <div className="card">
                    <div className="card-header with-border">
                        <h3 className="card-title">Stock Report</h3>
                    </div>
                    <div className="card-body">

                        {/* ── Filter row ── */}
                        <div className="row mb-3">
                            <div className="col-md-3 form-group">
                                <label>Product Name</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    placeholder="Enter product name"
                                    value={productName}
                                    onChange={(e) => setProductName(e.target.value)}
                                />
                            </div>
                            <div className="col-md-3 form-group">
                                <label>Product Type</label>
                                <Select
                                    options={productTypeOptions}
                                    value={productType}
                                    onChange={setProductType}
                                    placeholder="Select product type..."
                                    isClearable
                                    className="react-select-container"
                                    classNamePrefix="react-select"
                                    menuPosition="fixed"
                                />
                            </div>
                            <div className="col-md-4 form-group d-flex align-items-end gap-2">
                                <button className="btn-save" onClick={() => {}}>Filter</button>
                                <button className="btn-cancel" onClick={handleReset}>Reset</button>
                            </div>
                        </div>

                        {/* ── Table ── */}
                        <div className="table-responsive">
                            <table className="table table-bordered table-striped no-margin">
                                <thead>
                                    <tr>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Sno <TableSortIcon /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Product Type <TableSortIcon /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Product Name <TableSortIcon /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Total Qty <TableSortIcon /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Available Qty <TableSortIcon /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Last Updated <TableSortIcon /></div>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {DUMMY_DATA.map((row, idx) => (
                                        <tr key={row.id}>
                                            <td>{idx + 1}</td>
                                            <td>{row.productType}</td>
                                            <td>{row.productName}</td>
                                            <td className="tw-text-center">{row.totalQty}</td>
                                            <td className="tw-text-center">{row.availableQty}</td>
                                            <td>{row.lastUpdated}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </section>
    );
};

export default StockReport;
