import { Routes, Route } from 'react-router-dom';
import ReportList from './ReportList';
import ReportAdd from './ReportAdd';
import ReportEdit from './ReportEdit';
import StockReport from './StockReport';
import CustomerLedgerReport from './CustomerLedgerReport';
import VendorLedgerReport from './VendorLedgerReport';
import OutstandingReport from './OutstandingReport';
import EnquiryHoldReport from './EnquiryHoldReport';

export default function ReportRoutes() {
    return (
        <Routes>
            <Route path="" element={<ReportList />} />
            <Route path="add" element={<ReportAdd />} />
            <Route path="edit/:id" element={<ReportEdit />} />
            <Route path="stock-report" element={<StockReport />} />
            <Route path="customer-ledger" element={<CustomerLedgerReport />} />
            <Route path="vendor-ledger" element={<VendorLedgerReport />} />
            <Route path="outstanding-report" element={<OutstandingReport />} />
            <Route path="enquiry-hold" element={<EnquiryHoldReport />} />
        </Routes>
    );
}
