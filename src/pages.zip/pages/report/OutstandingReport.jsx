import { useState } from 'react';
import TableSortIcon from '../../components/TableSortIcon';

const DUMMY_DATA = [
    { id: 1, contraNumber: 'CON-1001', contraPerson: 'Rajesh Kumar',   amount: '45,000.00', contraDate: '02-06-2026', interest: '1,800.00' },
    { id: 2, contraNumber: 'CON-1002', contraPerson: 'Suresh Patel',   amount: '28,500.00', contraDate: '04-06-2026', interest: '950.00'   },
    { id: 3, contraNumber: 'CON-1003', contraPerson: 'Anand Sharma',   amount: '74,000.00', contraDate: '05-06-2026', interest: '3,200.00' },
    { id: 4, contraNumber: 'CON-1004', contraPerson: 'Priya Mehta',    amount: '12,750.00', contraDate: '07-06-2026', interest: '510.00'   },
    { id: 5, contraNumber: 'CON-1005', contraPerson: 'Vikram Reddy',   amount: '60,000.00', contraDate: '09-06-2026', interest: '2,400.00' },
];

const OutstandingReport = () => {
    const [contraNumber,  setContraNumber]  = useState('');
    const [contraPerson,  setContraPerson]  = useState('');
    const [contraDate,    setContraDate]    = useState('');

    const handleReset = () => {
        setContraNumber('');
        setContraPerson('');
        setContraDate('');
    };

    return (
        <section className="content">
            <div className="container-fluid">
                <div className="card">
                    <div className="card-header with-border">
                        <h3 className="card-title">Outstanding Report</h3>
                    </div>
                    <div className="card-body">

                        {/* ── Filter fields ── */}
                        <div className="row mb-3 align-items-end">
                            <div className="col-md-3 form-group">
                                <label>Contra Number</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    placeholder="Enter contra number"
                                    value={contraNumber}
                                    onChange={(e) => setContraNumber(e.target.value)}
                                />
                            </div>
                            <div className="col-md-3 form-group">
                                <label>Contra Person</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    placeholder="Enter contra person"
                                    value={contraPerson}
                                    onChange={(e) => setContraPerson(e.target.value)}
                                />
                            </div>
                            <div className="col-md-3 form-group">
                                <label>Contra Date</label>
                                <input
                                    type="date"
                                    className="form-control"
                                    placeholder="DD-MM-YYYY"
                                    value={contraDate}
                                    onChange={(e) => setContraDate(e.target.value)}
                                />
                            </div>
                            <div className="col-md-3 form-group d-flex align-items-end gap-2">
                                <button className="btn-save"   onClick={() => {}}>Filter</button>
                                <button className="btn-cancel" onClick={handleReset}>Reset</button>
                            </div>
                        </div>

                        {/* ── Table ── */}
                        <div className="table-responsive">
                            <table className="table table-bordered table-striped no-margin">
                                <thead>
                                    <tr>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Sno <TableSortIcon /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Contra Number <TableSortIcon /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Contra Person <TableSortIcon /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Amount <TableSortIcon /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Contra Date <TableSortIcon /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Interest <TableSortIcon /></div>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {DUMMY_DATA.map((row, idx) => (
                                        <tr key={row.id}>
                                            <td>{idx + 1}</td>
                                            <td>{row.contraNumber}</td>
                                            <td>{row.contraPerson}</td>
                                            <td className="tw-text-right">{row.amount}</td>
                                            <td>{row.contraDate}</td>
                                            <td className="tw-text-right">{row.interest}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </section>
    );
};

export default OutstandingReport;
