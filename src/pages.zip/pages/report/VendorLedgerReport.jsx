import { useState } from 'react';
import Select from 'react-select';
import TableSortIcon from '../../components/TableSortIcon';

const vendorOptions = [
    { value: 'v1', label: 'Saras Industry'       },
    { value: 'v2', label: 'Comptech Engineers'   },
    { value: 'v3', label: 'Global Air Systems'   },
    { value: 'v4', label: 'Power Tech Solutions' },
];

const DUMMY_DATA = [
    { id: 1, vendorName: 'Saras Industry',       invoiceNo: 'INV-2001', date: '02-06-2026', amount: '55,000.00', balance: '25,000.00' },
    { id: 2, vendorName: 'Comptech Engineers',   invoiceNo: 'INV-2002', date: '03-06-2026', amount: '32,500.00', balance: '0.00'      },
    { id: 3, vendorName: 'Global Air Systems',   invoiceNo: 'INV-2003', date: '05-06-2026', amount: '74,800.00', balance: '74,800.00' },
    { id: 4, vendorName: 'Power Tech Solutions', invoiceNo: 'INV-2004', date: '07-06-2026', amount: '18,200.00', balance: '5,000.00'  },
    { id: 5, vendorName: 'Saras Industry',       invoiceNo: 'INV-2005', date: '09-06-2026', amount: '41,000.00', balance: '41,000.00' },
];

const VendorLedgerReport = () => {
    const [vendor,   setVendor]   = useState(null);
    const [fromDate, setFromDate] = useState('01-06-2026');
    const [toDate,   setToDate]   = useState('10-06-2026');

    const handleReset = () => {
        setVendor(null);
        setFromDate('01-06-2026');
        setToDate('10-06-2026');
    };

    return (
        <section className="content">
            <div className="container-fluid">
                <div className="card">
                    <div className="card-header with-border">
                        <h3 className="card-title">Vendor Ledger Report</h3>
                    </div>
                    <div className="card-body">

                        {/* ── Filter fields ── */}
                        <div className="row mb-3 align-items-end">
                            <div className="col-md-3 form-group">
                                <label>Vendor Name</label>
                                <Select
                                    options={vendorOptions}
                                    value={vendor}
                                    onChange={setVendor}
                                    placeholder="Select Vendor"
                                    isClearable
                                    className="react-select-container"
                                    classNamePrefix="react-select"
                                    menuPosition="fixed"
                                />
                            </div>
                            <div className="col-md-3 form-group">
                                <label>From Date</label>
                                <input
                                    type="date"
                                    className="form-control"
                                    value={fromDate}
                                    onChange={(e) => setFromDate(e.target.value)}
                                />
                            </div>
                            <div className="col-md-3 form-group">
                                <label>To Date</label>
                                <input
                                    type="date"
                                    className="form-control"
                                    value={toDate}
                                    onChange={(e) => setToDate(e.target.value)}
                                />
                            </div>
                            <div className="col-md-3 form-group d-flex align-items-end gap-2">
                                <button className="btn-save"   onClick={() => {}}>Filter</button>
                                <button className="btn-cancel" onClick={handleReset}>Reset</button>
                            </div>
                        </div>

                        {/* ── Table ── */}
                        <div className="table-responsive">
                            <table className="table table-bordered table-striped no-margin">
                                <thead>
                                    <tr>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center"># <TableSortIcon /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Vendor Name <TableSortIcon /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Invoice No <TableSortIcon /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Date <TableSortIcon /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Amount <TableSortIcon /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Balance <TableSortIcon /></div>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {DUMMY_DATA.map((row, idx) => (
                                        <tr key={row.id}>
                                            <td>{idx + 1}</td>
                                            <td>{row.vendorName}</td>
                                            <td>{row.invoiceNo}</td>
                                            <td>{row.date}</td>
                                            <td className="tw-text-right">{row.amount}</td>
                                            <td className="tw-text-right">{row.balance}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </section>
    );
};

export default VendorLedgerReport;
