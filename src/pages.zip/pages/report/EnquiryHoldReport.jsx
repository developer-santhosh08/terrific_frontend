import { useState } from 'react';
import Select from 'react-select';
import TableSortIcon from '../../components/TableSortIcon';

const enqNoOptions = [
    { value: 'ENQ-1001', label: 'ENQ-1001' },
    { value: 'ENQ-1002', label: 'ENQ-1002' },
    { value: 'ENQ-1003', label: 'ENQ-1003' },
    { value: 'ENQ-1004', label: 'ENQ-1004' },
    { value: 'ENQ-1005', label: 'ENQ-1005' },
];

const mobileOptions = [
    { value: '9876543210', label: '9876543210' },
    { value: '9876543211', label: '9876543211' },
    { value: '9876543212', label: '9876543212' },
    { value: '9876543213', label: '9876543213' },
    { value: '9876543214', label: '9876543214' },
];

const allottedToOptions = [
    { value: 'rajesh-kumar',  label: 'Rajesh Kumar'  },
    { value: 'suresh-patel',  label: 'Suresh Patel'  },
    { value: 'anand-sharma',  label: 'Anand Sharma'  },
    { value: 'priya-mehta',   label: 'Priya Mehta'   },
    { value: 'vikram-reddy',  label: 'Vikram Reddy'  },
];

const DUMMY_DATA = [
    { id: 1, enqNo: 'ENQ-1001', enqDate: '02-06-2026', comttDate: '03-06-2026', mobile: '9876543210', vertical: 'Compressor', allottedTo: 'Rajesh Kumar',  currentStage: 'Hold' },
    { id: 2, enqNo: 'ENQ-1002', enqDate: '03-06-2026', comttDate: '04-06-2026', mobile: '9876543211', vertical: 'Spares',     allottedTo: 'Suresh Patel',  currentStage: 'Hold' },
    { id: 3, enqNo: 'ENQ-1003', enqDate: '05-06-2026', comttDate: '06-06-2026', mobile: '9876543212', vertical: 'Service',    allottedTo: 'Anand Sharma',  currentStage: 'Hold' },
    { id: 4, enqNo: 'ENQ-1004', enqDate: '07-06-2026', comttDate: '08-06-2026', mobile: '9876543213', vertical: 'Compressor', allottedTo: 'Priya Mehta',   currentStage: 'Hold' },
    { id: 5, enqNo: 'ENQ-1005', enqDate: '09-06-2026', comttDate: '10-06-2026', mobile: '9876543214', vertical: 'Spares',     allottedTo: 'Vikram Reddy',  currentStage: 'Hold' },
];

const EnquiryHoldReport = () => {
    const [enqNo,      setEnqNo]      = useState(null);
    const [mobile,     setMobile]     = useState(null);
    const [allottedTo, setAllottedTo] = useState(null);

    const handleReset = () => {
        setEnqNo(null);
        setMobile(null);
        setAllottedTo(null);
    };

    return (
        <section className="content">
            <div className="container-fluid">
                <div className="card">
                    <div className="card-header with-border">
                        <h3 className="card-title">Enquiry Hold Report</h3>
                    </div>
                    <div className="card-body">

                        {/* ── Filter fields ── */}
                        <div className="row mb-3 align-items-end">
                            <div className="col-md-3 form-group">
                                <label>Enquiry No</label>
                                <Select
                                    options={enqNoOptions}
                                    value={enqNo}
                                    onChange={setEnqNo}
                                    placeholder="Select enquiry no..."
                                    isClearable
                                    className="react-select-container"
                                    classNamePrefix="react-select"
                                    menuPosition="fixed"
                                />
                            </div>
                            <div className="col-md-3 form-group">
                                <label>Mobile</label>
                                <Select
                                    options={mobileOptions}
                                    value={mobile}
                                    onChange={setMobile}
                                    placeholder="Select mobile..."
                                    isClearable
                                    className="react-select-container"
                                    classNamePrefix="react-select"
                                    menuPosition="fixed"
                                />
                            </div>
                            <div className="col-md-3 form-group">
                                <label>Allotted To</label>
                                <Select
                                    options={allottedToOptions}
                                    value={allottedTo}
                                    onChange={setAllottedTo}
                                    placeholder="Select person..."
                                    isClearable
                                    className="react-select-container"
                                    classNamePrefix="react-select"
                                    menuPosition="fixed"
                                />
                            </div>
                            <div className="col-md-3 form-group d-flex align-items-end gap-2">
                                <button className="btn-save"   onClick={() => {}}>Filter</button>
                                <button className="btn-cancel" onClick={handleReset}>Reset</button>
                            </div>
                        </div>

                        {/* ── Table ── */}
                        <div className="table-responsive">
                            <table className="table table-bordered table-striped no-margin">
                                <thead>
                                    <tr>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center"># <TableSortIcon /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Enq. No <TableSortIcon /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Enq. Date <TableSortIcon /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Comtt. Date <TableSortIcon /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Mobile <TableSortIcon /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Vertical <TableSortIcon /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Allotted To <TableSortIcon /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50">
                                            <div className="tw-flex tw-justify-between tw-items-center">Current Stage <TableSortIcon /></div>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {DUMMY_DATA.map((row, idx) => (
                                        <tr key={row.id}>
                                            <td>{idx + 1}</td>
                                            <td>{row.enqNo}</td>
                                            <td>{row.enqDate}</td>
                                            <td>{row.comttDate}</td>
                                            <td>{row.mobile}</td>
                                            <td>{row.vertical}</td>
                                            <td>{row.allottedTo}</td>
                                            <td>{row.currentStage}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </section>
    );
};

export default EnquiryHoldReport;
