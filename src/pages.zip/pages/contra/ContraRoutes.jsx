import { Routes, Route } from 'react-router-dom';
import ContraList from './ContraList';
import ContraAdd from './ContraAdd';
import ContraEdit from './ContraEdit';
import ContraReciptList from './ContraReciptList';

export default function ContraRoutes() {
    return (
        <Routes>
            <Route path="" element={<ContraList />} />
            <Route path="add" element={<ContraAdd />} />
            <Route path="edit/:id" element={<ContraEdit />} />
            <Route path="receipt" element={<ContraReciptList />} />
        </Routes>
    );
}
