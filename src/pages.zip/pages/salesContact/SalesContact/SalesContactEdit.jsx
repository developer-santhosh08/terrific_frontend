import React, { useState, useEffect } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { CaretLeft } from '@phosphor-icons/react';
import Select from 'react-select';
import UpdatePopup from '../../../components/Popup/UpdatePopup.jsx';
import { useLoader } from '../../../context/LoaderContext';

const statusOptions = [
    { value: 1, label: 'Infollowup' },
    { value: 2, label: 'Closed' },
    { value: 3, label: 'Converted' },
    { value: 4, label: 'Hold' }
];

const SalesContactEdit = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const location = useLocation();
    const returnUrl = location.state?.from || '/sales-contact';
    const { setLoading } = useLoader();

    const [engineerOptions, setEngineerOptions] = useState([]);
    const [cityOptions, setCityOptions] = useState([]);
    const [customerOptions, setCustomerOptions] = useState([]);

    const [formData, setFormData] = useState({
        created_date: '',
        customer_name: '',
        mobile_number1: '',
        mobile_number2: '',
        address: '',
        next_followup: '',
        remarks: '',
        referred_by: ''
    });

    const [selectedEngineer, setSelectedEngineer] = useState(null);
    const [selectedCustomer, setSelectedCustomer] = useState(null);
    const [selectedCity, setSelectedCity] = useState(null);
    const [selectedReferrer, setSelectedReferrer] = useState(null);
    const [selectedStatus, setSelectedStatus] = useState(null);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [showUpdatePopup, setShowUpdatePopup] = useState(false);

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                const token = sessionStorage.getItem('erp_token');
                const headers = {
                    'Accept': 'application/json',
                    ...(token ? { 'Authorization': `Bearer ${token}` } : {})
                };

                // Fetch options
                const [engRes, cityRes, custRes] = await Promise.all([
                    fetch(`${import.meta.env.VITE_API_BASE_URL}/api/salescontact/engineers`, { headers }).catch(() => null),
                    fetch(`${import.meta.env.VITE_API_BASE_URL}/api/master/geolocation?type=city`, { headers }).catch(() => null),
                    fetch(`${import.meta.env.VITE_API_BASE_URL}/api/master/dropdown/customer`, { headers }).catch(() => null)
                ]);

                let fetchedEngineers = [];
                let fetchedCities = [];
                let fetchedCustomers = [];

                if (engRes) {
                    const json = await engRes.json().catch(() => null);
                    const data = Array.isArray(json) ? json : (json?.data || []);
                    fetchedEngineers = data.map(e => ({ value: e.id, label: e.name || e.engineer_name || e.employee_name }));
                    setEngineerOptions(fetchedEngineers);
                }

                if (cityRes) {
                    const json = await cityRes.json().catch(() => null);
                    const data = Array.isArray(json) ? json : (json?.data || []);
                    fetchedCities = data.map(c => ({ value: c.id, label: c.city_name || c.city || c.name }));
                    setCityOptions(fetchedCities);
                }

                if (custRes) {
                    const json = await custRes.json().catch(() => null);
                    const data = Array.isArray(json) ? json : (json?.data || []);
                    const uniqueCustomers = Array.from(new Map(data.map(c => [(c.name || '').trim().toUpperCase(), c])).values());
                    fetchedCustomers = uniqueCustomers.map(item => ({
                        value: item.id || item.customer_id || item.name,
                        label: item.name || item.customer_name || item.id
                    }));
                    setCustomerOptions(fetchedCustomers);
                }

                // Fetch record data
                const recordRes = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/salescontact/sales-contact/${id}`, { headers });
                const recordJson = await recordRes.json();

                if (recordJson && recordJson.data) {
                    const c = recordJson.data;
                    setFormData({
                        created_date: c.created_date || c.date || c.created_at || '',
                        mobile_number1: c.mobile_number1 || c.mobile || '',
                        mobile_number2: c.mobile_number2 || c.mobile2 || '',
                        address: c.address || c.billing_address1 || c.address_line1 || c.billing_address || '',
                        next_followup: c.next_followup || c.next_follow_date || c.next_followup_date || c.next_date || '',
                        remarks: c.remarks || c.remark || c.description || '',
                    });

                    const allottedToVal = c.allottedTo || c.allotted_to || c.engineer || c.engineer_id;
                    if (allottedToVal) {
                        const eng = fetchedEngineers.find(e => String(e.value) === String(allottedToVal) || String(e.label).toLowerCase() === String(allottedToVal).toLowerCase());
                        if (eng) setSelectedEngineer(eng);
                    }

                    const cityVal = c.city || c.city_id || c.city_name;
                    if (cityVal) {
                        const cit = fetchedCities.find(e => String(e.value) === String(cityVal) || String(e.label).toLowerCase() === String(cityVal).toLowerCase());
                        if (cit) setSelectedCity(cit);
                    }

                    const custVal = c.customer_name || c.customer || c.customer_id;
                    if (custVal) {
                        const cust = fetchedCustomers.find(e => String(e.label).toLowerCase() === String(custVal).toLowerCase() || String(e.value) === String(custVal));
                        if (cust) setSelectedCustomer(cust);
                        else setSelectedCustomer({ value: custVal, label: custVal });
                    }

                    const refVal = c.referred_by || c.referredBy || c.referrer;
                    if (refVal) {
                        const ref = fetchedCustomers.find(e => String(e.label).toLowerCase() === String(refVal).toLowerCase() || String(e.value) === String(refVal));
                        if (ref) setSelectedReferrer(ref);
                        else setSelectedReferrer({ value: refVal, label: refVal });
                    }

                    const statusVal = c.contact_status || c.status || c.current_stage || c.currentStage;
                    if (statusVal) {
                        const st = statusOptions.find(e => String(e.value).toLowerCase().replace(/\s/g, '') === String(statusVal).toLowerCase().replace(/\s/g, ''));
                        if (st) setSelectedStatus(st);
                        else setSelectedStatus({ value: statusVal, label: statusVal });
                    }
                }
            } catch (err) {
                console.error("Error fetching data:", err);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [id]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleCustomerChange = async (selectedOption) => {
        setSelectedCustomer(selectedOption);
        if (!selectedOption) {
            setFormData(prev => ({
                ...prev,
                mobile_number1: '',
                mobile_number2: '',
                address: ''
            }));
            setSelectedCity(null);
            return;
        }

        try {
            const token = sessionStorage.getItem('erp_token');
            const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/enquiry/customers/${selectedOption.value}`, {
                headers: {
                    'Accept': 'application/json',
                    ...(token ? { 'Authorization': `Bearer ${token}` } : {})
                }
            });
            const json = await res.json();
            if (json.status === 'success' && json.data) {
                const c = json.data;
                const matchedCity = cityOptions.find(opt => opt.value === c.city_id || opt.value === c.city);
                setFormData(prev => ({
                    ...prev,
                    mobile_number1: c.mobile_number1 || c.mobile || '',
                    mobile_number2: c.mobile_number2 || '',
                    address: c.billing_address1 || c.address_line1 || c.address || ''
                }));
                if (matchedCity) {
                    setSelectedCity(matchedCity);
                }
            }
        } catch (err) {
            console.error('Error fetching customer details:', err);
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        setShowUpdatePopup(true);
    };

    const handleConfirmSubmit = async () => {
        setIsSubmitting(true);
        try {
            const token = sessionStorage.getItem('erp_token');
            const payload = {
                created_date: formData.created_date,
                customer_name: selectedCustomer ? selectedCustomer.label : '',
                mobile_number1: formData.mobile_number1,
                mobile_number2: formData.mobile_number2,
                address: formData.address,
                city: selectedCity ? selectedCity.value : null,
                next_followup: formData.next_followup,
                allottedTo: selectedEngineer ? selectedEngineer.value : null,
                remarks: formData.remarks,
                referred_by: selectedReferrer ? selectedReferrer.label : '',
                contact_status: selectedStatus ? selectedStatus.value : 1
            };

            const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/salescontact/sales-contact/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    ...(token ? { 'Authorization': `Bearer ${token}` } : {})
                },
                body: JSON.stringify(payload)
            });

            const data = await response.json();
            if (response.ok && data.status === 'success') {
                navigate(returnUrl);
            } else {
                console.error('Failed to update sales contact:', data);
                alert(data.message || 'Failed to update');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('An error occurred while saving.');
        } finally {
            setIsSubmitting(false);
            setShowUpdatePopup(false);
        }
    };

    return (
        <section className="content">
            <div className="container-fluid">
                <div className="card">
                    <div className="card-header with-border d-flex justify-content-between align-items-center">
                        <h3 className="card-title">Edit SalesContact</h3>
                        <button className="btn-header-back" onClick={() => navigate('/sales-contact')}>
                            Back
                        </button>
                    </div>
                    <div className="card-body">
                        <form onSubmit={handleSubmit}>
                            <div className="row">
                                <div className="col-md-3 form-group">
                                    <label>Engineer Name<span className="text-danger">*</span></label>
                                    <Select
                                        options={engineerOptions}
                                        placeholder="Choose a Person"
                                        value={selectedEngineer}
                                        onChange={setSelectedEngineer}
                                        required
                                    />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>Customer Name <span className="text-danger">*</span></label>
                                    <Select
                                        options={customerOptions}
                                        placeholder="Choose a Customer"
                                        value={selectedCustomer}
                                        onChange={handleCustomerChange}
                                        required
                                    />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>Mobile Number1 <span className="text-danger">*</span></label>
                                    <input type="text" name="mobile_number1" value={formData.mobile_number1} onChange={handleInputChange} className="form-control" placeholder="Mobile Number1" required />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>Mobile Number2</label>
                                    <input type="text" name="mobile_number2" value={formData.mobile_number2} onChange={handleInputChange} className="form-control" placeholder="Mobile Number2" />
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-md-3 form-group">
                                    <label>Address</label>
                                    <input type="text" name="address" value={formData.address} onChange={handleInputChange} className="form-control" placeholder="Billing Address" />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>City <span className="text-danger">*</span></label>
                                    <Select
                                        options={cityOptions}
                                        placeholder="Choose a City.."
                                        value={selectedCity}
                                        onChange={setSelectedCity}
                                        required
                                    />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>Next Followup Date <span className="text-danger">*</span></label>
                                    <input type="date" name="next_followup" value={formData.next_followup} onChange={handleInputChange} className="form-control" required />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>Date <span className="text-danger">*</span></label>
                                    <input type="date" name="created_date" value={formData.created_date} onChange={handleInputChange} className="form-control" required />
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-md-3 form-group">
                                    <label>Remark</label>
                                    <input type="text" name="remarks" value={formData.remarks} onChange={handleInputChange} className="form-control" placeholder="remark" />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>Referred by</label>
                                    <Select
                                        options={customerOptions}
                                        placeholder="Choose a Referrer"
                                        value={selectedReferrer}
                                        onChange={setSelectedReferrer}
                                        isClearable
                                    />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>Contact Status</label>
                                    <Select
                                        options={statusOptions}
                                        placeholder="Select Status"
                                        value={selectedStatus}
                                        onChange={setSelectedStatus}
                                        isClearable
                                    />
                                </div>
                            </div>
                            <div className="form-actions mt-3 d-flex justify-content-between">
                                <button type="button" className="btn-cancel" onClick={() => navigate(returnUrl)} disabled={isSubmitting}>Cancel</button>
                                <button type="submit" className="btn-save" disabled={isSubmitting}>
                                    {isSubmitting ? 'Updating...' : 'Update'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <UpdatePopup isOpen={showUpdatePopup} onClose={() => setShowUpdatePopup(false)} onConfirm={handleConfirmSubmit} />
        </section>
    );
};

export default SalesContactEdit;
