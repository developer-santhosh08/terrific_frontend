import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { CaretLeft } from '@phosphor-icons/react';
import Select from 'react-select';
import SubmitPopup from '../../../components/Popup/SubmitPopup.jsx';
import { useLoader } from '../../../context/LoaderContext';

const statusOptions = [
    { value: 1, label: 'Infollowup' },
    { value: 2, label: 'Closed' },
    { value: 3, label: 'Converted' },
    { value: 4, label: 'Hold' }
];

const SalesContactAdd = () => {
    const { setLoading } = useLoader();
    const navigate = useNavigate();
    const [engineerOptions, setEngineerOptions] = useState([]);
    const [cityOptions, setCityOptions] = useState([]);
    const [customerOptions, setCustomerOptions] = useState([]);

    const [formData, setFormData] = useState({
        created_date: new Date().toISOString().split('T')[0],
        mobile_number1: '',
        mobile_number2: '',
        address: '',
        next_followup: '',
        remarks: '',
        referred_by: ''
    });

    const [selectedEngineer, setSelectedEngineer] = useState(null);
    const [selectedCustomer, setSelectedCustomer] = useState(null);
    const [selectedCity, setSelectedCity] = useState(null);
    const [selectedReferrer, setSelectedReferrer] = useState(null);
    const [selectedStatus, setSelectedStatus] = useState(statusOptions[0]);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [showSubmitPopup, setShowSubmitPopup] = useState(false);

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                const token = sessionStorage.getItem('erp_token');
                const headers = {
                    'Accept': 'application/json',
                    ...(token ? { 'Authorization': `Bearer ${token}` } : {})
                };

                const [engRes, cityRes, custRes] = await Promise.all([
                    fetch(`${import.meta.env.VITE_API_BASE_URL}/api/salescontact/engineers`, { headers }).catch(() => null),
                    fetch(`${import.meta.env.VITE_API_BASE_URL}/api/master/geolocation?type=city`, { headers }).catch(() => null),
                    fetch(`${import.meta.env.VITE_API_BASE_URL}/api/master/dropdown/customer`, { headers }).catch(() => null)
                ]);

                if (engRes) {
                    const json = await engRes.json().catch(() => ({}));
                    const data = Array.isArray(json) ? json : (json?.data || []);
                    setEngineerOptions(data.map(item => ({
                        value: item.id || item.name || item.engineer_name || item.employee_name,
                        label: item.name || item.engineer_name || item.employee_name || item.id
                    })));
                }

                if (cityRes) {
                    const json = await cityRes.json().catch(() => ({}));
                    const data = Array.isArray(json) ? json : (Array.isArray(json?.data) ? json.data : []);
                    setCityOptions(data.map(item => ({
                        value: item.id || item.name || item.city_name,
                        label: item.name || item.city_name || item.id
                    })));
                }

                if (custRes) {
                    const json = await custRes.json().catch(() => ({}));
                    const data = Array.isArray(json) ? json : (Array.isArray(json?.data) ? json.data : []);
                    const uniqueCustomers = Array.from(new Map(data.map(c => [(c.name || '').trim().toUpperCase(), c])).values());
                    setCustomerOptions(uniqueCustomers.map(item => ({
                        value: item.id || item.customer_id || item.name,
                        label: item.name || item.customer_name || item.id
                    })));
                }

            } catch (err) {
                console.error("Error setup fetching:", err);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, []);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleCustomerChange = async (selectedOption) => {
        setSelectedCustomer(selectedOption);
        if (!selectedOption) {
            setFormData(prev => ({
                ...prev,
                mobile_number1: '',
                mobile_number2: '',
                address: ''
            }));
            setSelectedCity(null);
            return;
        }

        try {
            const token = sessionStorage.getItem('erp_token');
            const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/enquiry/customers/${selectedOption.value}`, {
                headers: {
                    'Accept': 'application/json',
                    ...(token ? { 'Authorization': `Bearer ${token}` } : {})
                }
            });
            const json = await res.json();
            if (json.status === 'success' && json.data) {
                const c = json.data;
                const matchedCity = cityOptions.find(opt => opt.value === c.city_id || opt.value === c.city);
                setFormData(prev => ({
                    ...prev,
                    mobile_number1: c.mobile_number1 || c.mobile || '',
                    mobile_number2: c.mobile_number2 || '',
                    address: c.billing_address1 || c.address_line1 || c.address || ''
                }));
                if (matchedCity) {
                    setSelectedCity(matchedCity);
                }
            }
        } catch (err) {
            console.error('Error fetching customer details:', err);
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        setShowSubmitPopup(true);
    };

    const handleConfirmSubmit = async () => {
        setIsSubmitting(true);
        try {
            const token = sessionStorage.getItem('erp_token');
            const payload = {
                created_date: formData.created_date,
                customer_name: selectedCustomer ? selectedCustomer.label : '',
                mobile_number1: formData.mobile_number1,
                mobile_number2: formData.mobile_number2,
                address: formData.address,
                city: selectedCity ? selectedCity.value : null,
                next_followup: formData.next_followup,
                allottedTo: selectedEngineer ? selectedEngineer.value : null,
                remarks: formData.remarks,
                referred_by: selectedReferrer ? selectedReferrer.label : '',
                contact_status: selectedStatus ? selectedStatus.value : 1
            };

            const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/salescontact/sales-contact`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    ...(token ? { 'Authorization': `Bearer ${token}` } : {})
                },
                body: JSON.stringify(payload)
            });

            const data = await response.json();
            if (response.ok && data.status === 'success') {
                navigate('/sales-contact');
            } else {
                console.error('Failed to save sales contact:', data);
                alert(data.message || 'Failed to save');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('An error occurred while saving.');
        } finally {
            setIsSubmitting(false);
            setShowSubmitPopup(false);
        }
    };

    return (
        <section className="content">
            <div className="container-fluid">
                <div className="card">
                    <div className="card-header with-border d-flex justify-content-between align-items-center">
                        <h3 className="card-title">Add Sales Contact</h3>
                        <button type="button" className="btn-header-back" onClick={() => navigate('/sales-contact')}>
                            Back
                        </button>
                    </div>
                    <div className="card-body">
                        <form onSubmit={handleSubmit}>
                            <div className="row">
                                <div className="col-md-3 form-group">
                                    <label>Engineer Name<span className="text-danger">*</span></label>
                                    <Select
                                        options={engineerOptions}
                                        placeholder="Choose a Person"
                                        value={selectedEngineer}
                                        onChange={setSelectedEngineer}
                                        required
                                    />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>Customer Name <span className="text-danger">*</span></label>
                                    <Select
                                        options={customerOptions}
                                        placeholder="Choose a Customer"
                                        value={selectedCustomer}
                                        onChange={handleCustomerChange}
                                        required
                                    />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>Mobile Number1 <span className="text-danger">*</span></label>
                                    <input type="text" name="mobile_number1" value={formData.mobile_number1} onChange={handleInputChange} className="form-control" placeholder="Mobile Number1" required />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>Mobile Number2</label>
                                    <input type="text" name="mobile_number2" value={formData.mobile_number2} onChange={handleInputChange} className="form-control" placeholder="Mobile Number2" />
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-md-3 form-group">
                                    <label>Address</label>
                                    <input type="text" name="address" value={formData.address} onChange={handleInputChange} className="form-control" placeholder="Billing Address" />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>City <span className="text-danger">*</span></label>
                                    <Select
                                        options={cityOptions}
                                        placeholder="Choose a City.."
                                        value={selectedCity}
                                        onChange={setSelectedCity}
                                        required
                                    />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>Next Followup Date <span className="text-danger">*</span></label>
                                    <input type="date" name="next_followup" value={formData.next_followup} onChange={handleInputChange} className="form-control" required />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>Date <span className="text-danger">*</span></label>
                                    <input type="date" name="created_date" value={formData.created_date} onChange={handleInputChange} className="form-control" required />
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-md-3 form-group">
                                    <label>Remark</label>
                                    <input type="text" name="remarks" value={formData.remarks} onChange={handleInputChange} className="form-control" placeholder="remark" />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>Referred by</label>
                                    <Select
                                        options={customerOptions}
                                        placeholder="Choose a Referrer"
                                        value={selectedReferrer}
                                        onChange={setSelectedReferrer}
                                        isClearable
                                    />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>Contact Status</label>
                                    <Select
                                        options={statusOptions}
                                        placeholder="Select Status"
                                        value={selectedStatus}
                                        onChange={setSelectedStatus}
                                        isClearable
                                    />
                                </div>
                            </div>
                            <div className="card-footer d-flex justify-content-between tw-mt-4">
                                <button type="button" className="btn-cancel" onClick={() => navigate('/sales-contact')} disabled={isSubmitting}>Cancel</button>
                                <button type="submit" className="btn-save" disabled={isSubmitting}>
                                    {isSubmitting ? 'Submitting...' : 'Submit'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <SubmitPopup isOpen={showSubmitPopup} onClose={() => setShowSubmitPopup(false)} onConfirm={handleConfirmSubmit} />
        </section>
    );
};

export default SalesContactAdd;
