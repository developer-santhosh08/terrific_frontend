import { Routes, Route } from 'react-router-dom';
import SalesContactList from './SalesContact/SalesContactList';
import SalesContactAdd from './SalesContact/SalesContactAdd';
import SalesContactEdit from './SalesContact/SalesContactEdit';
import ClosedContactList from './closedContact/ClosedContactList';
import ConvertedContactList from './convertedContact/ConvertedContactList';

export default function SalesContactRoutes() {
    return (
        <Routes>
            <Route path="" element={<SalesContactList />} />
            <Route path="add" element={<SalesContactAdd />} />
            <Route path="edit/:id" element={<SalesContactEdit />} />
            <Route path="closed" element={<ClosedContactList />} />
            <Route path="converted" element={<ConvertedContactList />} />
        </Routes>
    );
}
