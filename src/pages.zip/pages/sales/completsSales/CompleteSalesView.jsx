import { useLoader } from '../../../context/LoaderContext';
import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';

const CompleteSalesView = () => {
    const { setLoading } = useLoader();
    const navigate = useNavigate();
    const { id } = useParams();

    // Dummy data matching the image
    const data = {
        customerName: 'POWER GREEN EQUIPMENTS',
        enquiryNumber: '8183',
        allottedTo: 'RAMESH P',
        products: [
            { id: 1, name: 'TERRIFIC-TF-7.5 VFD-7.5kw-40 cfm @ 8 bar, 35 cfm @ 10 bar', unit: '1', price: '153400.00' }
        ]
    };

    return (
        <section className="content">
            <div className="container-fluid">
                <div className="card">
                    <div className="card-header with-border d-flex justify-content-between align-items-center">
                        <h3 className="card-title">Completed Sales View</h3>
                        <button 
                            className="btn-header-back"
                            onClick={() => navigate('/sales/complete-sales')}
                        >
                            Back
                        </button>
                    </div>
                    
                    <div className="card-body">
                        {/* ── Top info bar ─────────────────────── */}
                        <div
                            className="tw-mb-5"
                            style={{
                                background: '#cce9f7', borderRadius: 6,
                                padding: '14px 24px',
                                display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 0,
                            }}
                        >
                            <div style={{ flex: 1, minWidth: 220, display: 'flex', alignItems: 'center', gap: 8 }}>
                                <span style={{ color: '#4a6a7c', fontSize: 14 }}>Customer Name</span>
                                <span style={{ color: '#4a6a7c', fontSize: 14 }}>:</span>
                                <span style={{ color: '#0f2d40', fontSize: 14, fontWeight: 700 }}>{data.customerName}</span>
                            </div>
                            <div style={{ flex: 1, minWidth: 220, display: 'flex', alignItems: 'center', gap: 8 }}>
                                <span style={{ color: '#4a6a7c', fontSize: 14 }}>Enquiry Number</span>
                                <span style={{ color: '#4a6a7c', fontSize: 14 }}>:</span>
                                <span style={{ color: '#0f2d40', fontSize: 14, fontWeight: 700 }}>{data.enquiryNumber}</span>
                            </div>
                            <div style={{ flex: 1, minWidth: 200, display: 'flex', alignItems: 'center', gap: 8 }}>
                                <span style={{ color: '#4a6a7c', fontSize: 14 }}>Allotted To</span>
                                <span style={{ color: '#4a6a7c', fontSize: 14 }}>:</span>
                                <span style={{ color: '#0f2d40', fontSize: 14, fontWeight: 700 }}>{data.allottedTo}</span>
                            </div>
                        </div>

                        {/* Products Table */}
                        <div className="table-responsive">
                            <table className="table table-bordered table-striped no-margin">
                                <thead>
                                    <tr>
                                        <th className="tw-w-16">S.No</th>
                                        <th>Product Name</th>
                                        <th className="tw-w-24">Unit</th>
                                        <th className="tw-w-40 tw-text-right">Price</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {data.products.map((item, index) => (
                                        <tr key={item.id}>
                                            <td>{index + 1}</td>
                                            <td>{item.name}</td>
                                            <td>{item.unit}</td>
                                            <td className="tw-text-right">{item.price}</td>
                                        </tr>
                                    ))}
                                    {data.products.length === 0 && (
                                        <tr>
                                            <td colSpan="4" className="tw-text-center tw-text-slate-400 tw-py-4">No products found</td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default CompleteSalesView;
