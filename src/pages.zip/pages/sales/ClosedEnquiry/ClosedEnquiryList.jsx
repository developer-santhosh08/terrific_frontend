import { useLoader } from '../../../context/LoaderContext';
import SmartPagination from '../../../components/SmartPagination';
import { useTableControls } from '../../../hooks/useTableControls';
import { useState, useMemo, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { PencilSimpleIcon, ArrowBendUpLeftIcon } from '@phosphor-icons/react';
import TableSortIcon from '../../../components/TableSortIcon';
import RevertPopup from '../../../components/Popup/RevertPopup';

const ClosedEnquiryList = () => {
    const { setLoading } = useLoader();
    const [closedData, setClosedData] = useState([]);
    const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });
    const handleSort = (key) => {
        let direction = 'asc';
        if (sortConfig.key === key && sortConfig.direction === 'asc') direction = 'desc';
        setSortConfig({ key, direction });
    };

    const navigate = useNavigate();
    const [searchTerm, setSearchTerm] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(10);
    const getSortDirection = (key) => sortConfig.key === key ? sortConfig.direction : null;

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                const [custRes, stageRes, res] = await Promise.all([
                    fetch(`${import.meta.env.VITE_API_BASE_URL}/api/master/dropdown/customer`),
                    fetch(`${import.meta.env.VITE_API_BASE_URL}/api/master/dropdown/terrific_stages`),
                    fetch(`${import.meta.env.VITE_API_BASE_URL}/api/enquiry/enquiry/status/closed`)
                ]);

                const [custJson, stageJson, json] = await Promise.all([
                    custRes.json(),
                    stageRes.json(),
                    res.json()
                ]);

                const custMap = {};
                if (custJson.status && custJson.data) custJson.data.forEach(c => custMap[c.id] = c.name);

                const stageMap = {};
                if (stageJson.status && stageJson.data) stageJson.data.forEach(s => stageMap[s.id] = s.name);

                if (json.status === 'success' && json.data) {
                    const mappedData = json.data.map(item => ({
                        id: item.id,
                        enqNo: item.enquiry_number || '',
                        enqDate: item.enquiry_date || '',
                        customerName: custMap[item.customer_id] || item.cust_contact_name || item.customer_id || 'Unknown',
                        mobile: item.mobile_number1 || '',
                        nextFollowUpDate: item.last_committed_date || '',
                        currentStage: item.current_stage || stageMap[item.stage_id] || 'Closed'
                    }));
                    setClosedData(mappedData);
                }
            } catch (err) {
                console.error('Error fetching closed data:', err);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [setLoading]);

    const [revertPopupOpen, setRevertPopupOpen] = useState(false);
    const [enquiryToRevert, setEnquiryToRevert] = useState(null);

    const confirmRevert = (id) => {
        setEnquiryToRevert(id);
        setRevertPopupOpen(true);
    };

    const handleRevert = async () => {
        if (!enquiryToRevert) return;
        try {
            const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/enquiry/enquiry/${enquiryToRevert}/revert`, {
                method: 'PUT'
            });
            const json = await res.json();
            if (json.status === 'success') {
                setRevertPopupOpen(false);
                setClosedData(prev => prev.filter(item => item.id !== enquiryToRevert));
                setEnquiryToRevert(null);
            } else {
                alert(json.message || 'Failed to revert enquiry');
            }
        } catch (err) {
            console.error('Error reverting enquiry:', err);
            alert('An error occurred while reverting the enquiry');
        }
    };


    const filteredData = useMemo(() => {
        let data = [...closedData];
        if (searchTerm) {
            const lowerSearch = searchTerm.toLowerCase();
            data = data.filter(item =>
                item.enqNo?.toLowerCase().includes(lowerSearch) ||
                item.customerName?.toLowerCase().includes(lowerSearch) ||
                item.mobile?.toLowerCase().includes(lowerSearch) ||
                item.currentStage?.toLowerCase().includes(lowerSearch)
            );
        }
        if (sortConfig.key) {
            data.sort((a, b) => {
                if (a[sortConfig.key] < b[sortConfig.key]) return sortConfig.direction === 'asc' ? -1 : 1;
                if (a[sortConfig.key] > b[sortConfig.key]) return sortConfig.direction === 'asc' ? 1 : -1;
                return 0;
            });
        }
        return data;
    }, [searchTerm, sortConfig, closedData]);

    const totalPages = Math.max(1, Math.ceil(filteredData.length / itemsPerPage));
    const startIndex = (currentPage - 1) * itemsPerPage;
    const paginatedData = filteredData.slice(startIndex, startIndex + itemsPerPage);

    return (
        <section className="content">
            <style>{`
                .ce-action-icon {
                    width: 32px; height: 32px; border-radius: 4px; border: none;
                    display: inline-flex; align-items: center; justify-content: center;
                    cursor: pointer; transition: background-color .12s ease;
                }
                .ce-action-icon:focus { outline: none; }
                .ce-edit   { background-color: #3b82f6; color: #ffffff; }
                .ce-edit:hover   { background-color: #2563eb; }
                .ce-delete { background-color: #ef4444; color: #ffffff; }
                .ce-delete:hover { background-color: #dc2626; }
            `}</style>
            <div className="container-fluid">
                <div className="card">
                    <div className="card-header with-border d-flex justify-content-between align-items-center">
                        <h3 className="card-title">Closed Enquiry List</h3>
                    </div>

                    <div className="card-body">
                        {/* Table Controls */}
                        <div className="list-top-bar">
                            <div className="tw-flex tw-items-center tw-gap-2">
                                <span>Show</span>
                                <select
                                    className="form-select form-select-sm tw-w-20 tw-inline-block"
                                    value={itemsPerPage}
                                    onChange={(e) => {
                                        setItemsPerPage(Number(e.target.value));
                                        setCurrentPage(1);
                                    }}
                                >
                                    <option value="10">10</option>
                                    <option value="25">25</option>
                                    <option value="50">50</option>
                                    <option value="100">100</option>
                                </select>
                                <span>entries</span>
                            </div>

                            <div className="tw-flex tw-items-center tw-gap-2">
                                <span>Search:</span>
                                <input
                                    type="text"
                                    className="form-control form-control-sm tw-w-48 tw-inline-block"
                                    value={searchTerm}
                                    onChange={(e) => { setSearchTerm(e.target.value); setCurrentPage(1); }}
                                />
                            </div>
                        </div>

                        {/* Table */}
                        <div className="table-responsive">
                            <table className="table table-bordered table-striped no-margin">
                                <thead>
                                    <tr>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50" onClick={() => handleSort('id')}>
                                            <div className="tw-flex tw-justify-between tw-items-center"># <TableSortIcon direction={getSortDirection('id')} /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50" onClick={() => handleSort('enqNo')}>
                                            <div className="tw-flex tw-justify-between tw-items-center">Enq. No <TableSortIcon direction={getSortDirection('enqNo')} /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50" onClick={() => handleSort('enqDate')}>
                                            <div className="tw-flex tw-justify-between tw-items-center">Enq. Date <TableSortIcon direction={getSortDirection('enqDate')} /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50" onClick={() => handleSort('customerName')}>
                                            <div className="tw-flex tw-justify-between tw-items-center">Customer Name <TableSortIcon direction={getSortDirection('customerName')} /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50" onClick={() => handleSort('mobile')}>
                                            <div className="tw-flex tw-justify-between tw-items-center">Mobile <TableSortIcon direction={getSortDirection('mobile')} /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50" onClick={() => handleSort('nextFollowUpDate')}>
                                            <div className="tw-flex tw-justify-between tw-items-center">Next FollowUp Date <TableSortIcon direction={getSortDirection('nextFollowUpDate')} /></div>
                                        </th>
                                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50" onClick={() => handleSort('currentStage')}>
                                            <div className="tw-flex tw-justify-between tw-items-center">Current Stage <TableSortIcon direction={getSortDirection('currentStage')} /></div>
                                        </th>
                                        <th className="tw-align-middle">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {paginatedData.map((row, idx) => (
                                        <tr key={row.id}>
                                            <td>{startIndex + idx + 1}</td>
                                            <td>{row.enqNo}</td>
                                            <td>{row.enqDate}</td>
                                            <td>{row.customerName}</td>
                                            <td>{row.mobile}</td>
                                            <td>{row.nextFollowUpDate}</td>
                                            <td>
                                                <span className="tw-bg-red-500 tw-text-white tw-px-2 tw-py-1 tw-rounded tw-text-xs tw-font-semibold">
                                                    {row.currentStage}
                                                </span>
                                            </td>
                                            <td>
                                                <div className="tw-flex tw-gap-2 tw-items-center">
                                                    {/* <button
                                                        type="button"
                                                        className="list-action-btn btn-edit"
                                                        title="Edit"
                                                        onClick={() => navigate(`/enquiry/edit/${row.id}`)}
                                                    >
                                                        <i className="bi bi-pencil" />
                                                    </button> */}
                                                    <button
                                                        type="button"
                                                        className="list-action-btn btn-delete"
                                                        title="Revert Enquiry"
                                                        onClick={() => confirmRevert(row.id)}
                                                    >
                                                        <ArrowBendUpLeftIcon weight="duotone" className="tw-w-4" />
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                    {paginatedData.length === 0 && (
                                        <tr>
                                            <td colSpan="8" className="tw-text-center tw-text-slate-400 tw-py-8">No data available in table</td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>

                        {/* Pagination */}
                        <SmartPagination 
                            currentPage={currentPage}
                            totalPages={totalPages}
                            onPageChange={setCurrentPage}
                            startIndex={startIndex}
                            entriesPerPage={itemsPerPage}
                            totalEntries={filteredData.length}
                        />

                        {/* Revert Popup */}
                        <RevertPopup
                            isOpen={revertPopupOpen}
                            onClose={() => setRevertPopupOpen(false)}
                            onConfirm={handleRevert}
                        />

                    </div>
                </div>
            </div>
        </section>
    );
};

export default ClosedEnquiryList;
