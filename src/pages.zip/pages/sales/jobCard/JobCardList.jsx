import { useLoader } from '../../../context/LoaderContext';
import SmartPagination from '../../../components/SmartPagination';
import { useTableControls } from '../../../hooks/useTableControls';
import { useState, useEffect, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { PencilSimpleIcon, PlusIcon, Printer, ArrowBendUpLeftIcon } from '@phosphor-icons/react';
import TableSortIcon from '../../../components/TableSortIcon';
import { useSortableData } from '../../../hooks/useSortableData';
import QuotationPopup from '../../../components/Popup/QuotationPopup';
import RevertPopup from '../../../components/Popup/RevertPopup';
import SuccessPopup from '../../../components/Popup/SuccessPopup';
import ErrorPopup from '../../../components/Popup/ErrorPopup';


/* ── Badge styles ─────────────────────────────────────────────── */
const CATEGORY_STYLE = {
    'Converted': { bg: '#10b981', color: '#ffffff' },
    'In Followup': { bg: '#3b82f6', color: '#ffffff' },
};

const STAGE_STYLE = {
    'Job Card': { bg: '#f59e0b', color: '#000000' },
    'Receipt': { bg: '#8b5cf6', color: '#ffffff' },
    'Completed': { bg: '#10b981', color: '#ffffff' },
    'Pending': { bg: '#ef4444', color: '#ffffff' },
};

const Badge = ({ value, map, color }) => {
    const { setLoading } = useLoader();
    const st = map[value] || { bg: color || '#22c55e', color: '#ffffff' };
    return (
        <span style={{ background: color || st.bg, color: st.color, padding: '2px 10px', borderRadius: 3, whiteSpace: 'nowrap', fontSize: 12 }}>
            {value || '-'}
        </span>
    );
};

/* ── Component ────────────────────────────────────────────────── */
const JobCardList = () => {
    const { setLoading } = useLoader();
    const navigate = useNavigate();
    const location = useLocation();
    const [activeTab, setActiveTab] = useState(location.state?.defaultTab || 'jobcard');
    const [searchText, setSearchText] = useState('');
    const [pageSize, setPageSize] = useState(10);
    const [currentPage, setCurrentPage] = useState(1);

    const [jobcards, setJobcards] = useState([]);
    const [erections, setErections] = useState([]);

    const { items: sortedJobcard, requestSort: reqSortJobcard, getSortDirection: getSortDirJobcard } = useSortableData(jobcards);
    const { items: sortedErection, requestSort: reqSortErection, getSortDirection: getSortDirErection } = useSortableData(erections);

    const [quotationPopupRow, setQuotationPopupRow] = useState(null);
    const [revertPopupId, setRevertPopupId] = useState(null);
    const [successMessage, setSuccessMessage] = useState('');
    const [errorMessage, setErrorMessage] = useState('');

    const fetchJobCards = useCallback(async () => {
        try {
            const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/sales/jobcards`);
            const result = await res.json();
            if (result.status && result.data) {
                const mappedData = result.data.map(item => ({
                    id: item.enquiry_header_id,
                    enqNo: item.enq_no,
                    enqDate: item.comt_date ? item.comt_date.split(' ')[0] : '-',
                    customerName: item.customer_name,
                    mobile: item.mobile,
                    category: 'Converted', // API only returns converted
                    currentStage: item.current_stage || 'Job Card',
                    stageColor: item.stage_color || null,
                    enquiry_status_id: item.enquiry_status_id
                }));
                setJobcards(mappedData);
            }
        } catch (error) {
            console.error("Error fetching job cards:", error);
        }
    }, []);

    const fetchErections = useCallback(async () => {
        try {
            const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/sales/jobcards/erection-list`);
            const result = await res.json();
            if (result.status && result.data) {
                const mappedData = result.data.map(item => ({
                    id: item.enquiry_header_id,
                    enqNo: item.enq_no,
                    enqDate: item.comt_date ? item.comt_date.split(' ')[0] : '-',
                    customerName: item.customer_name,
                    mobile: item.mobile,
                    category: 'Converted',
                    currentStage: item.current_stage || 'Completed Job Card',
                    stageColor: item.stage_color || null,
                    enquiry_status_id: item.enquiry_status_id
                }));
                setErections(mappedData);
            }
        } catch (error) {
            console.error("Error fetching erection list:", error);
        }
    }, []);

    useEffect(() => {
        const loadAll = async () => {
            setLoading(true);
            await Promise.all([fetchJobCards(), fetchErections()]);
            setLoading(false);
        };
        loadAll();
    }, [fetchJobCards, fetchErections, setLoading]);

    const confirmRevertJobCard = async () => {
        if (!revertPopupId) return;
        
        try {
            setLoading(true);
            const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/sales/jobcards/erection/revert/${revertPopupId}`, {
                method: 'PUT'
            });
            const result = await res.json();
            if (result.status) {
                setRevertPopupId(null);
                setSuccessMessage(result.message);
                fetchJobCards();
                fetchErections();
            } else {
                setErrorMessage(result.message || "Failed to revert Job Card");
            }
        } catch (error) {
            console.error("Error reverting job card:", error);
            setErrorMessage("Error reverting job card");
        } finally {
            setLoading(false);
        }
    };

    const renderActionButtons = (tabKey, row) => {
        if (tabKey === 'jobcard') {
            return (
                <div className="tw-flex tw-gap-2 tw-items-center">
                    <button type="button" className="list-action-btn btn-edit" title="Edit" onClick={() => navigate(`/sales/job-card/add`, { state: { editId: row.id } })}>
                        <PencilSimpleIcon weight="duotone" className="tw-w-4" />
                    </button>
                    <button type="button" className="list-action-btn btn-add" title="Quotation" onClick={() => setQuotationPopupRow(row)}>
                        <PlusIcon weight="bold" className="tw-w-4" />
                    </button>
                    <button type="button" className="list-action-btn btn-print" title="Print" onClick={() => window.open(`/enquiry/proformaQuotation/${row.id}`, '_blank')}>
                        <Printer weight="duotone" className="tw-w-4" />
                    </button>
                </div>
            );
        } else if (tabKey === 'erection') {
            return (
                <div className="tw-flex tw-gap-2 tw-items-center">
                    {(!row.enquiry_status_id || row.enquiry_status_id <= 5) && (
                        <button type="button" className="list-action-btn btn-edit" title="Edit" onClick={() => navigate(`/sales/erection/edit/${row.id}`)}>
                            <PencilSimpleIcon weight="duotone" className="tw-w-4" />
                        </button>
                    )}
                    <button type="button" className="list-action-btn btn-add" title="Quotation" onClick={() => setQuotationPopupRow(row)}>
                        <PlusIcon weight="bold" className="tw-w-4" />
                    </button>
                    <button type="button" className="list-action-btn btn-print" title="Print" onClick={() => window.open(`/enquiry/proformaQuotation/${row.id}`, '_blank')}>
                        <Printer weight="duotone" className="tw-w-4" />
                    </button>
                    {(!row.enquiry_status_id || row.enquiry_status_id <= 5) && (
                        <button type="button" className="list-action-btn btn-revert" title="Revert to Job Card" onClick={() => setRevertPopupId(row.id)}>
                            <ArrowBendUpLeftIcon weight="bold" className="tw-w-4" />
                        </button>
                    )}
                </div>
            );
        }
    };

    const renderTable = (items, requestSort, getSortDirection, startIndex, tabKey) => (
        <div className="table-responsive">
            <table className="table table-bordered table-striped no-margin">
                <thead>
                    <tr>
                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50" onClick={() => requestSort('id')}>
                            <div className="tw-flex tw-justify-between tw-items-center"># <TableSortIcon direction={getSortDirection('id')} /></div>
                        </th>
                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50" onClick={() => requestSort('enqNo')}>
                            <div className="tw-flex tw-justify-between tw-items-center">Enq. No <TableSortIcon direction={getSortDirection('enqNo')} /></div>
                        </th>
                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50" onClick={() => requestSort('enqDate')}>
                            <div className="tw-flex tw-justify-between tw-items-center">Enq. Date <TableSortIcon direction={getSortDirection('enqDate')} /></div>
                        </th>
                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50" onClick={() => requestSort('customerName')}>
                            <div className="tw-flex tw-justify-between tw-items-center">Customer Name <TableSortIcon direction={getSortDirection('customerName')} /></div>
                        </th>
                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50" onClick={() => requestSort('mobile')}>
                            <div className="tw-flex tw-justify-between tw-items-center">Mobile <TableSortIcon direction={getSortDirection('mobile')} /></div>
                        </th>
                        <th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50" onClick={() => requestSort('currentStage')}>
                            <div className="tw-flex tw-justify-between tw-items-center">Current Stage <TableSortIcon direction={getSortDirection('currentStage')} /></div>
                        </th>

                        <th className="tw-align-middle">Action</th>
                    </tr>
                </thead>
                <tbody>
                    {items.map((r, idx) => (
                        <tr key={r.id}>
                            <td>{startIndex + idx + 1}</td>
                            <td>{r.enqNo}</td>
                            <td>{r.enqDate}</td>
                            <td>{r.customerName}</td>
                            <td>{r.mobile}</td>
                            <td><Badge value={r.currentStage} map={STAGE_STYLE} color={r.stageColor} /></td>

                            <td>
                                {renderActionButtons(tabKey, r)}
                            </td>
                        </tr>
                    ))}
                    {items.length === 0 && (
                        <tr>
                            <td colSpan="9" className="tw-text-center tw-text-slate-400 tw-py-8">No records found</td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    );

    return (
        <section className="content">
            <style>{`
                .sv-action-icon {
                    width: 28px; height: 28px; border-radius: 8px; border: none;
                    display: inline-flex; align-items: center; justify-content: center;
                    cursor: pointer; transition: background-color .12s ease, transform .06s ease;
                    box-shadow: 0 4px 8px rgba(0,0,0,0.10);
                }
                .sv-action-icon:hover { transform: translateY(-1px); }
                .sv-action-icon:focus { outline: none; }
                .sv-edit  { background-color: #f59e0b; color: #000000; }
                .sv-edit:hover  { background-color: #d97706; }
                .sv-add   { background-color: #10b981; color: #ffffff; }
                .sv-add:hover   { background-color: #059669; }
                .sv-list  { background-color: #6366f1; color: #ffffff; }
                .sv-list:hover  { background-color: #4f46e5; }
                .sv-print { background-color: #06b6d4; color: #ffffff; }
                .sv-print:hover { background-color: #0891b2; }
                .btn-revert { background-color: #ef4444; color: #ffffff; }
                .btn-revert:hover { background-color: #dc2828; }
            `}</style>

            <div className="container-fluid">
                <div className="card">
                    <div className="card-header with-border d-flex justify-content-between align-items-center">
                        <h3 className="card-title">Job Card / Erection</h3>
                    </div>

                    <div className="card-body">
                        {/* Tabs */}
                        <div className="tw-flex tw-gap-2 tw-mb-3 tw-flex-wrap">
                            <button
                                type="button"
                                className={`tw-px-4 tw-py-2 tw-rounded-sm ${activeTab === 'jobcard' ? 'tw-bg-blue-600 tw-text-white' : 'tw-bg-white tw-border tw-text-gray-700'}`}
                                onClick={() => { setActiveTab('jobcard'); setCurrentPage(1); }}
                            >
                                Jobcard List
                            </button>
                            <button
                                type="button"
                                className={`tw-px-4 tw-py-2 tw-rounded-sm ${activeTab === 'erection' ? 'tw-bg-blue-600 tw-text-white' : 'tw-bg-white tw-border tw-text-gray-700'}`}
                                onClick={() => { setActiveTab('erection'); setCurrentPage(1); }}
                            >
                                Erection List
                            </button>
                        </div>

                        {/* Show / Search */}
                        <div className="list-top-bar">
                            <div className="tw-flex tw-items-center tw-gap-2">
                                <span>Show</span>
                                <select
                                    className="form-select form-select-sm tw-w-20 tw-inline-block"
                                    value={pageSize}
                                    onChange={e => { setPageSize(Number(e.target.value)); setCurrentPage(1); }}
                                >
                                    <option value="10">10</option>
                                    <option value="25">25</option>
                                    <option value="50">50</option>
                                    <option value="100">100</option>
                                </select>
                                <span>entries</span>
                            </div>
                            <div className="tw-flex tw-items-center tw-gap-2">
                                <span>Search:</span>
                                <input
                                    type="text"
                                    className="form-control form-control-sm tw-w-48 tw-inline-block"
                                    value={searchText}
                                    onChange={e => { setSearchText(e.target.value); setCurrentPage(1); }}
                                />
                            </div>
                        </div>

                        {/* Table + Pagination */}
                        {(() => {
                            let sourceItems = [];
                            let requestSort = null;
                            let getSortDir = null;

                            if (activeTab === 'jobcard') {
                                sourceItems = sortedJobcard;
                                requestSort = reqSortJobcard;
                                getSortDir = getSortDirJobcard;
                            } else if (activeTab === 'erection') {
                                sourceItems = sortedErection;
                                requestSort = reqSortErection;
                                getSortDir = getSortDirErection;
                            }
                            const q = searchText.trim().toLowerCase();
                            const filtered = q
                                ? sourceItems.filter(r =>
                                    String(r.enqNo || '').toLowerCase().includes(q) ||
                                    String(r.customerName || '').toLowerCase().includes(q) ||
                                    String(r.mobile || '').toLowerCase().includes(q)
                                )
                                : sourceItems;

                            const total = filtered.length;
                            const totalPages = Math.max(1, Math.ceil(total / pageSize));
                            const safePage = Math.min(currentPage, totalPages);
                            const startIndex = (safePage - 1) * pageSize;
                            const paginated = filtered.slice(startIndex, startIndex + pageSize);

                            return (
                                <>
                                    {renderTable(paginated, requestSort, getSortDir, startIndex, activeTab)}
                                    <SmartPagination 
                                        currentPage={safePage}
                                        totalPages={totalPages}
                                        onPageChange={setCurrentPage}
                                        startIndex={startIndex}
                                        entriesPerPage={pageSize}
                                        totalEntries={total}
                                    />
                                </>
                            );
                        })()}
                    </div>
                </div>
            </div>
            
            <QuotationPopup
                isOpen={!!quotationPopupRow}
                onClose={() => setQuotationPopupRow(null)}
                row={quotationPopupRow}
            />

            <RevertPopup
                isOpen={!!revertPopupId}
                onClose={() => setRevertPopupId(null)}
                onConfirm={confirmRevertJobCard}
                title="Revert Confirmation"
                message={<>Are you sure you want to <strong style={{ color: '#dc2626' }}>revert</strong> this Job Card? This will restore the stock and make the serial numbers available again.<br /></>}
            />

            <SuccessPopup
                isOpen={!!successMessage}
                onClose={() => setSuccessMessage('')}
                message={successMessage}
            />

            <ErrorPopup
                isOpen={!!errorMessage}
                onClose={() => setErrorMessage('')}
                message={errorMessage}
            />
        </section>
    );
};

export default JobCardList;
