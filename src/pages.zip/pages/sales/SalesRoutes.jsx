import { useLoader } from '../../context/LoaderContext';
import { Routes, Route } from 'react-router-dom';
import FollowupsList from './followups/FollowupsList';
import SiteVisitList from './siteVisit/SiteVisitList';
import SiteVisitEdit from './siteVisit/SiteVisitEdit';
import JobCardList from './jobCard/JobCardList';
import JobCardAdd from './jobCard/JobCardAdd';
import ErectionEdit from './jobCard/ErectionEdit';
import InvoiceList from './Invoice/InvoiceList';
import InvoiceEdit from './Invoice/InvoiceEdit';
import CompleteInvoiceEdit from './Invoice/CompleteInvoiceEdit';
import AdvancedReciptList from './advanceRecipt/AdvancedReciptList';
import AdvancedReciptCreate from './advanceRecipt/AdvancedReciptCreate';
import AdvancedReciptEdit from './advanceRecipt/AdvancedReciptEdit';

import CompleteSalesList from './completsSales/CompleteSalesList';
import CompleteSalesView from './completsSales/CompleteSalesView';
import UnallottedEnquiryList from './UnallottedEnquiry/UnallottedEnquiryList';
import ClosedEnquiryList from './ClosedEnquiry/ClosedEnquiryList';
import SalesReturnEnquiryList from './SalesReturn/EnqiuryList';
import FurtherReceiptList from './furtherReceipt/FurtherReceiptList';
import FurtherReceiptEdit from './furtherReceipt/FurtherReceiptEdit';
import FurtherReceiptUpdate from './furtherReceipt/FurtherReceiptUpdate';

export default function SalesRoutes() {
    const { setLoading } = useLoader();
    return (
        <Routes>
            <Route path="followups" element={<FollowupsList />} />
            <Route path="site-visit" element={<SiteVisitList />} />
            <Route path="site-visit/edit/:id" element={<SiteVisitEdit />} />
            <Route path="job-card" element={<JobCardList />} />
            <Route path="job-card/add" element={<JobCardAdd />} />
            <Route path="erection/edit/:id" element={<ErectionEdit />} />
            <Route path="invoice" element={<InvoiceList />} />
            <Route path="invoice/edit/:id" element={<InvoiceEdit />} />
            <Route path="complete-invoice/edit/:id" element={<CompleteInvoiceEdit />} />
            <Route path="advanced-receipt" element={<AdvancedReciptList />} />
            <Route path="advanced-receipt/add/:id" element={<AdvancedReciptCreate />} />
            <Route path="advanced-receipt/edit/:id" element={<AdvancedReciptEdit />} />

            <Route path="complete-sales" element={<CompleteSalesList />} />
            <Route path="complete-sales/view/:id" element={<CompleteSalesView />} />
            <Route path="unallotted-enquiry" element={<UnallottedEnquiryList />} />
            <Route path="closed-enquiry" element={<ClosedEnquiryList />} />
            <Route path="sales-return" element={<SalesReturnEnquiryList />} />
            <Route path="further-receipt" element={<FurtherReceiptList />} />
            <Route path="further-receipt/edit/:id" element={<FurtherReceiptEdit />} />
            <Route path="further-receipt/update/:id" element={<FurtherReceiptUpdate />} />
        </Routes>
    );
}
