import { Routes, Route } from 'react-router-dom';
import EnquiryList from './EnquiryList';
import EnquiryAdd from './EnquiryAdd';
import EnquiryEdit from './EnquiryEdit';
import EnquiryPrint from './EnquiryPrint';
import QuotationPdfPrint from './QuotationPdfPrint';
import ProformaPdfPrint from './ProformaPdfPrint';


export default function EnquiryRoutes() {
    return (
        <Routes>
            <Route path="" element={<EnquiryList />} />
            <Route path="add" element={<EnquiryAdd />} />
            <Route path="edit/:id" element={<EnquiryEdit />} />
            <Route path="print/:id" element={<EnquiryPrint />} />
            <Route path="quotationPdf/:id" element={<QuotationPdfPrint />} />
            <Route path="proformaQuotation/:id" element={<ProformaPdfPrint />} />
        </Routes>
    );
}
