import { Routes, Route } from 'react-router-dom';
import CompanyList from './company/company/CompanyList';
import CompanyAdd from './company/company/CompanyAdd';
import CompanyEdit from './company/company/CompanyEdit';
import BranchList from './company/branch/BranchList';
import BranchAdd from './company/branch/BranchAdd';
import BranchEdit from './company/branch/BranchEdit';
import TaxMasterList from './company/taxMaster/TaxMasterList';
import TaxMasterAdd from './company/taxMaster/TaxMasterAdd';
import TaxMasterEdit from './company/taxMaster/TaxMasterEdit';
import ProjectList from './company/project/ProjectList';
import ProjectAdd from './company/project/ProjectAdd';
import ProjectEdit from './company/project/ProjectEdit';

import EnquirySoruceList from './enquiry/enquirySource/EnquirySoruceList';
import EnquirySoruceAdd from './enquiry/enquirySource/EnquirySoruceAdd';
import EnquirySoruceEdit from './enquiry/enquirySource/EnquirySoruceEdit';
import PandFNotesList from './enquiry/p&f notes/P&fNotesList';
import PandFNotesAdd from './enquiry/p&f notes/P&fNotesAdd';
import PandFNotesEdit from './enquiry/p&f notes/P&fNotesEdit';

import TaxNotesList from './enquiry/taxNotes/TaxNotesList';
import TaxNotesAdd from './enquiry/taxNotes/TaxNotesAdd';
import TaxNotesEdit from './enquiry/taxNotes/TaxNotesEdit';

import PaymentNotesList from './enquiry/paymentNotes/PaymentNotesList';
import PaymentNotesAdd from './enquiry/paymentNotes/PaymentNotesAdd';
import PaymentNotesEdit from './enquiry/paymentNotes/PaymentNotesEdit';

import DeliveryNotesList from './enquiry/deliveryNotes/DeliveryNotesList';
import DeliveryNotesAdd from './enquiry/deliveryNotes/DeliveryNotesAdd';
import DeliveryNotesEdit from './enquiry/deliveryNotes/DeliveryNotesEdit';

import WarrantyNotesList from './enquiry/warrantyNotes/WarrantyNotesList';
import WarrantyNotesAdd from './enquiry/warrantyNotes/WarrantyNotesAdd';
import WarrantyNotesEdit from './enquiry/warrantyNotes/WarrantyNotesEdit';

import FrightNotesList from './enquiry/frightNotes/FrightNotesList';
import FrightNotesAdd from './enquiry/frightNotes/FrightNotesAdd';
import FrightNotesEdit from './enquiry/frightNotes/FrightNotesEdit';

import EnquiryEditList from './enquiryconfig/enquiryedit/EnquiryEditList';
import EnquiryEditAdd from './enquiryconfig/enquiryedit/EnquiryEditAdd';
import EnquiryEditEdit from './enquiryconfig/enquiryedit/EnquiryEditEdit';

import HrCategoryList from './hr/hrCategory/HrCategoryList';
import HrCategoryAdd from './hr/hrCategory/HrCategoryAdd';
import HrCategoryEdit from './hr/hrCategory/HrCategoryEdit';

import DesignationList from './hr/designation/DesignationList';
import DesignationAdd from './hr/designation/DesignationAdd';
import DesignationEdit from './hr/designation/DesignationEdit';

import DepartmentList from './hr/department/DepartmentList';
import DepartmentAdd from './hr/department/DepartmentAdd';
import DepartmentEdit from './hr/department/DepartmentEdit';

import MarketingPersonList from './hr/marketingperson/MarketingPersonList';
import MarketingPersonAdd from './hr/marketingperson/MarketingPersonAdd';
import MarketingPersonEdit from './hr/marketingperson/MarketingPersonEdit';

import AreaMarketingList from './hr/areamarketing/AreaMarketingList';
import AreaMarketingAdd from './hr/areamarketing/AreaMarketingAdd';
import AreaMarketingEdit from './hr/areamarketing/AreaMarketingEdit';

import LabourChargesList from './hr/labourcharges/LabourChargesList';
import LabourChargesAdd from './hr/labourcharges/LabourChargesAdd';
import LabourChargesEdit from './hr/labourcharges/LabourChargesEdit';

import CountyList from './geolocations/country/CountyList';
import CountyAdd from './geolocations/country/CountyAdd';
import CountyEdit from './geolocations/country/CountyEdit';
import AreaList from './geolocations/area/AreaList';
import AreaAdd from './geolocations/area/AreaAdd';
import AreaEdit from './geolocations/area/AreaEdit';
import EmployeeTypeList from './employee/employeetype/EmployeeTypeList';
import EmployeeTypeAdd from './employee/employeetype/EmployeeTypeAdd';
import EmployeeTypeEdit from './employee/employeetype/EmployeeTypeEdit';
import EmployeeList from './employee/employee/EmployeeList';
import EmployeeAdd from './employee/employee/EmployeeAdd';
import EmployeeEdit from './employee/employee/EmployeeEdit';
import EmployeeBrandList from './employee/employeebrand/EmployeeBrandList';
import EmployeeBrandAdd from './employee/employeebrand/EmployeeBrandAdd';
import EmployeeBrandEdit from './employee/employeebrand/EmployeeBrandEdit';
import EmployeeBusinessList from './employee/employeebusiness/EmployeeBusinessList';
import EmployeeBusinessAdd from './employee/employeebusiness/EmployeeBusinessAdd';
import EmployeeBusinessEdit from './employee/employeebusiness/EmployeeBusinessEdit';
import StateList from './geolocations/state/StateList';
import StateAdd from './geolocations/state/StateAdd';
import StateEdit from './geolocations/state/StateEdit';
import CityList from './geolocations/city/CityList';
import CityAdd from './geolocations/city/CityAdd';
import CityEdit from './geolocations/city/CityEdit';
import DistrictList from './geolocations/district/DistrictList'; // assuming it exists
import DistrictAdd from './geolocations/district/DistrictAdd';
import DistrictEdit from './geolocations/district/DistrictEdit';
import UserGroupList from './user/usergroup/UserGroupList';
import UserGroupAdd from './user/usergroup/UserGroupAdd';
import UserGroupEdit from './user/usergroup/UserGroupEdit';
import UserRightList from './user/userrights/UserRightList';
import UserRightAdd from './user/userrights/UserRightAdd';
import UserRightEdit from './user/userrights/UserRightEdit';
import UserMasterList from './user/usermaster/UserMasterList';
import UserMasterAdd from './user/usermaster/UserMasterAdd';
import UserMasterEdit from './user/usermaster/UserMasterEdit';
import MenuListList from './user/menulist/MenuListList';
import MenuListAdd from './user/menulist/MenuListAdd';
import MenuListEdit from './user/menulist/MenuListEdit';
import ContraPersonList from './contra/contraperson/ContraPersonList';
import ContraPersonAdd from './contra/contraperson/ContraPersonAdd';
import ContraPersonEdit from './contra/contraperson/ContraPersonEdit';

import BankList from './bank/bank/BankList';
import BankAdd from './bank/bank/BankAdd';
import BankEdit from './bank/bank/BankEdit';
import PaymentModeList from './bank/paymentmode/PaymentModeList';
import PaymentModeAdd from './bank/paymentmode/PaymentModeAdd';
import PaymentModeEdit from './bank/paymentmode/PaymentModeEdit';
import AccountDetailsList from './bank/accountdetails/AccountDetailsList';
import AccountDetailsAdd from './bank/accountdetails/AccountDetailsAdd';
import AccountDetailsEdit from './bank/accountdetails/AccountDetailsEdit';
import ChequeBookList from './bank/chequebook/ChequeBookList';
import ChequeBookAdd from './bank/chequebook/ChequeBookAdd';
import ChequeBookEdit from './bank/chequebook/ChequeBookEdit';
import AccountsCategoryList from './bank/accountscategory/AccountsCategoryList';
import AccountsCategoryAdd from './bank/accountscategory/AccountsCategoryAdd';
import AccountsCategoryEdit from './bank/accountscategory/AccountsCategoryEdit';
import AccountsHeadList from './bank/accountshead/AccountsHeadList';
import AccountsHeadAdd from './bank/accountshead/AccountsHeadAdd';
import AccountsHeadEdit from './bank/accountshead/AccountsHeadEdit';
import BudgetDetailsList from './bank/budgetdetails/BudgetDetailsList';
import BudgetDetailsAdd from './bank/budgetdetails/BudgetDetailsAdd';
import BudgetDetailsEdit from './bank/budgetdetails/BudgetDetailsEdit';

import CustomerCategoryList from './customer/customercategory/CustomerCategoryList';
import CustomerCategoryAdd from './customer/customercategory/CustomerCategoryAdd';
import CustomerCategoryEdit from './customer/customercategory/CustomerCategoryEdit';

import CustomerList from './customer/customer/CustomerList';
import CustomerAdd from './customer/customer/CustomerAdd';
import CustomerEdit from './customer/customer/CustomerEdit';

import CustomerSubList from './customer/customersubcategory/CustomerSubList';
import CustomerSubAdd from './customer/customersubcategory/CustomerSubAdd';
import CustomerSubEdit from './customer/customersubcategory/CustomerSubEdit';

import CustomerGroupList from './customer/customergroup/CustomerGroupList';
import CustomerGroupAdd from './customer/customergroup/CustomerGroupAdd';
import CustomerGroupEdit from './customer/customergroup/CustomerGroupEdit';

import CustomerGradingList from './customer/customergrading/CustomerGradingList';
import CustomerGradingAdd from './customer/customergrading/CustomerGradingAdd';
import CustomerGradingEdit from './customer/customergrading/CustomerGradingEdit';

import BrandList from './items/brand/BrandList';
import BrandAdd from './items/brand/BrandAdd';
import BrandEdit from './items/brand/BrandEdit';

import ProductGroupList from './items/productgroup/ProductGroupList';
import ProductGroupAdd from './items/productgroup/ProductGroupAdd';
import ProductGroupEdit from './items/productgroup/ProductGroupEdit';

import ProductCategoryList from './items/productcategory/ProductCategoryList';
import ProductCategoryAdd from './items/productcategory/ProductCategoryAdd';
import ProductCategoryEdit from './items/productcategory/ProductCategoryEdit';

import ProductSubList from './items/productsubcategory/ProductSubList';
import ProductSubAdd from './items/productsubcategory/ProductSubAdd';
import ProductSubEdit from './items/productsubcategory/ProductSubEdit';

import ProductModelList from './items/productmodel/ProductModelList';
import ProductModelAdd from './items/productmodel/ProductModelAdd';
import ProductModelEdit from './items/productmodel/ProductModelEdit';

import ProductList from './items/product/ProductList';
import ProductAdd from './items/product/ProductAdd';
import ProductEdit from './items/product/ProductEdit';

import StockLocationList from './items/stocklocation/StockLocationList';
import StockLocationAdd from './items/stocklocation/StockLocationAdd';
import StockLocationEdit from './items/stocklocation/StockLocationEdit';

import InspectionQuestionsList from './items/inspectionquestions/InspectionQuestionsList';
import InspectionQuestionsAdd from './items/inspectionquestions/InspectionQuestionsAdd';
import InspectionQuestionsEdit from './items/inspectionquestions/InspectionQuestionsEdit';

import ProductInspectionList from './items/productinspection/ProductInspectionList';
import ProductInspectionAdd from './items/productinspection/ProductInspectionAdd';
import ProductInspectionEdit from './items/productinspection/ProductInspectionEdit';

import VendorCategoryList from './vendor/vendorcategory/VendorCategoryList';
import VendorCategoryAdd from './vendor/vendorcategory/VendorCategoryAdd';
import VendorCategoryEdit from './vendor/vendorcategory/VendorCategoryEdit';

import VendorList from './vendor/vendor/VendorList';
import VendorAdd from './vendor/vendor/VendorAdd';
import VendorEdit from './vendor/vendor/VendorEdit';
import VendorMappingList from './vendor/vendorproduct/VendorMappingList';
import VendorMappingAdd from './vendor/vendorproduct/VendorMappingAdd';
import VendorMappingEdit from './vendor/vendorproduct/VendorMappingEdit';

import VendorSubList from './vendor/vendorsubcategory/VendorSubList';
import VendorSubAdd from './vendor/vendorsubcategory/VendorSubAdd';
import VendorSubEdit from './vendor/vendorsubcategory/VendorSubEdit';

import VendorGroupList from './vendor/vendorgroup/VendorGroupList';
import VendorGroupAdd from './vendor/vendorgroup/VendorGroupAdd';
import VendorGroupEdit from './vendor/vendorgroup/VendorGroupEdit';

import UnitList from './items/unit/UnitList';
import UnitAdd from './items/unit/UnitAdd';
import UnitEdit from './items/unit/UnitEdit';

import FeedbackParameterList from './feedback/feedbackparameter/FeedbackParameterList';
import FeedbackParameterAdd from './feedback/feedbackparameter/FeedbackParameterAdd';
import FeedbackParameterEdit from './feedback/feedbackparameter/FeedbackParameterEdit';

import SmsList from './reminder/sms/SmsList';
import SmsAdd from './reminder/sms/SmsAdd';
import SmsEdit from './reminder/sms/SmsEdit';

import EmailList from './reminder/email/EmailList';
import EmailAdd from './reminder/email/EmailAdd';
import EmailEdit from './reminder/email/EmailEdit';

import BulkSmsList from './bulksms/bulksms/BulkSmsList';
import BulkSmsAdd from './bulksms/bulksms/BulkSmsAdd';
import BulkSmsEdit from './bulksms/bulksms/BulkSmsEdit';

import TransporterModeList from './transporter/transportermode/TransporterModeList';
import TransporterModeAdd from './transporter/transportermode/TransporterModeAdd';
import TransporterModeEdit from './transporter/transportermode/TransporterModeEdit';
import TransporterDetailsList from './transporter/transporterdetails/TransporterDetailsList';
import TransporterDetailsAdd from './transporter/transporterdetails/TransporterDetailsAdd';
import TransporterDetailsEdit from './transporter/transporterdetails/TransporterDetailsEdit';

export default function PowerMasterRoutes() {
    return (
        <Routes>
            <Route path="company" element={<CompanyList />} />
            <Route path="company/add" element={<CompanyAdd />} />
            <Route path="company/edit/:id" element={<CompanyEdit />} />
            <Route path="branch" element={<BranchList />} />
            <Route path="branch/add" element={<BranchAdd />} />
            <Route path="branch/edit/:id" element={<BranchEdit />} />
            <Route path="tax-master" element={<TaxMasterList />} />
            <Route path="tax-master/add" element={<TaxMasterAdd />} />
            <Route path="tax-master/edit/:id" element={<TaxMasterEdit />} />
            <Route path="project" element={<ProjectList />} />
            <Route path="project/add" element={<ProjectAdd />} />
            <Route path="project/edit/:id" element={<ProjectEdit />} />
            <Route path="enquiry-source" element={<EnquirySoruceList />} />
            <Route path="enquiry-source/add" element={<EnquirySoruceAdd />} />
            <Route path="enquiry-source/edit/:id" element={<EnquirySoruceEdit />} />
            <Route path="pf-notes" element={<PandFNotesList />} />
            <Route path="pf-notes/add" element={<PandFNotesAdd />} />
            <Route path="pf-notes/edit/:id" element={<PandFNotesEdit />} />
            <Route path="tax-notes" element={<TaxNotesList />} />
            <Route path="tax-notes/add" element={<TaxNotesAdd />} />
            <Route path="tax-notes/edit/:id" element={<TaxNotesEdit />} />
            <Route path="payment-notes" element={<PaymentNotesList />} />
            <Route path="payment-notes/add" element={<PaymentNotesAdd />} />
            <Route path="payment-notes/edit/:id" element={<PaymentNotesEdit />} />
            <Route path="delivery-notes" element={<DeliveryNotesList />} />
            <Route path="delivery-notes/add" element={<DeliveryNotesAdd />} />
            <Route path="delivery-notes/edit/:id" element={<DeliveryNotesEdit />} />
            <Route path="warranty-notes" element={<WarrantyNotesList />} />
            <Route path="warranty-notes/add" element={<WarrantyNotesAdd />} />
            <Route path="warranty-notes/edit/:id" element={<WarrantyNotesEdit />} />
            <Route path="fright-notes" element={<FrightNotesList />} />
            <Route path="fright-notes/add" element={<FrightNotesAdd />} />
            <Route path="fright-notes/edit/:id" element={<FrightNotesEdit />} />

            <Route path="enquiryconfig/enquiryeditconfig" element={<EnquiryEditList />} />
            <Route path="enquiryconfig/enquiryeditconfig/add" element={<EnquiryEditAdd />} />
            <Route path="enquiryconfig/enquiryeditconfig/edit/:id" element={<EnquiryEditEdit />} />

            <Route path="hr/hr-category" element={<HrCategoryList />} />
            <Route path="hr/hr-category/add" element={<HrCategoryAdd />} />
            <Route path="hr/hr-category/edit/:id" element={<HrCategoryEdit />} />
            <Route path="hr/designation" element={<DesignationList />} />
            <Route path="hr/designation/add" element={<DesignationAdd />} />
            <Route path="hr/designation/edit/:id" element={<DesignationEdit />} />
            <Route path="hr/department" element={<DepartmentList />} />
            <Route path="hr/department/add" element={<DepartmentAdd />} />
            <Route path="hr/department/edit/:id" element={<DepartmentEdit />} />

            <Route path="hr/marketing-person" element={<MarketingPersonList />} />
            <Route path="hr/marketing-person/add" element={<MarketingPersonAdd />} />
            <Route path="hr/marketing-person/edit/:id" element={<MarketingPersonEdit />} />

            <Route path="hr/area-marketing-person" element={<AreaMarketingList />} />
            <Route path="hr/area-marketing-person/add" element={<AreaMarketingAdd />} />
            <Route path="hr/area-marketing-person/edit/:id" element={<AreaMarketingEdit />} />

            <Route path="hr/labour-charges" element={<LabourChargesList />} />
            <Route path="hr/labour-charges/add" element={<LabourChargesAdd />} />
            <Route path="hr/labour-charges/edit/:id" element={<LabourChargesEdit />} />
            <Route path="geolocations/country" element={<CountyList />} />
            <Route path="geolocations/country/add" element={<CountyAdd />} />
            <Route path="geolocations/country/edit/:id" element={<CountyEdit />} />
            <Route path="geolocations/area" element={<AreaList />} />
            <Route path="geolocations/area/add" element={<AreaAdd />} />
            <Route path="geolocations/area/edit/:id" element={<AreaEdit />} />
            <Route path="geolocations/state" element={<StateList />} />
            <Route path="geolocations/state/add" element={<StateAdd />} />
            <Route path="geolocations/state/edit/:id" element={<StateEdit />} />
            <Route path="geolocations/city" element={<CityList />} />
            <Route path="geolocations/city/add" element={<CityAdd />} />
            <Route path="geolocations/city/edit/:id" element={<CityEdit />} />
            <Route path="geolocations/district" element={<DistrictList />} />
            <Route path="geolocations/district/add" element={<DistrictAdd />} />
            <Route path="geolocations/district/edit/:id" element={<DistrictEdit />} />
            <Route path="employee/employee-type" element={<EmployeeTypeList />} />
            <Route path="employee/employee-type/add" element={<EmployeeTypeAdd />} />
            <Route path="employee/employee-type/edit/:id" element={<EmployeeTypeEdit />} />
            <Route path="employee/employee" element={<EmployeeList />} />
            <Route path="employee/employee/add" element={<EmployeeAdd />} />
            <Route path="employee/employee/edit/:id" element={<EmployeeEdit />} />
            <Route path="employee/brand-mapping" element={<EmployeeBrandList />} />
            <Route path="employee/brand-mapping/add" element={<EmployeeBrandAdd />} />
            <Route path="employee/brand-mapping/edit/:id" element={<EmployeeBrandEdit />} />
            <Route path="employee/business-vertical-mapping" element={<EmployeeBusinessList />} />
            <Route path="employee/business-vertical-mapping/add" element={<EmployeeBusinessAdd />} />
            <Route path="employee/business-vertical-mapping/edit/:id" element={<EmployeeBusinessEdit />} />
            <Route path="user/user-group" element={<UserGroupList />} />
            <Route path="user/user-group/add" element={<UserGroupAdd />} />
            <Route path="user/user-group/edit/:id" element={<UserGroupEdit />} />
            <Route path="user/user-right" element={<UserRightList />} />
            <Route path="user/user-right/add" element={<UserRightAdd />} />
            <Route path="user/user-right/edit/:id" element={<UserRightEdit />} />
            <Route path="user/user-master" element={<UserMasterList />} />
            <Route path="user/user-master/add" element={<UserMasterAdd />} />
            <Route path="user/user-master/edit/:id" element={<UserMasterEdit />} />
            <Route path="user/menu-list" element={<MenuListList />} />
            <Route path="user/menu-list/add" element={<MenuListAdd />} />
            <Route path="user/menu-list/edit/:id" element={<MenuListEdit />} />
            <Route path="contra/contra-person" element={<ContraPersonList />} />
            <Route path="contra/contra-person/add" element={<ContraPersonAdd />} />
            <Route path="contra/contra-person/edit/:id" element={<ContraPersonEdit />} />

            <Route path="bank/bank" element={<BankList />} />
            <Route path="bank/bank/add" element={<BankAdd />} />
            <Route path="bank/bank/edit/:id" element={<BankEdit />} />
            <Route path="bank/payment-mode" element={<PaymentModeList />} />
            <Route path="bank/payment-mode/add" element={<PaymentModeAdd />} />
            <Route path="bank/payment-mode/edit/:id" element={<PaymentModeEdit />} />
            <Route path="bank/account-details" element={<AccountDetailsList />} />
            <Route path="bank/account-details/add" element={<AccountDetailsAdd />} />
            <Route path="bank/account-details/edit/:id" element={<AccountDetailsEdit />} />
            <Route path="bank/cheque-book" element={<ChequeBookList />} />
            <Route path="bank/cheque-book/add" element={<ChequeBookAdd />} />
            <Route path="bank/cheque-book/edit/:id" element={<ChequeBookEdit />} />
            <Route path="bank/accounts-category" element={<AccountsCategoryList />} />
            <Route path="bank/accounts-category/add" element={<AccountsCategoryAdd />} />
            <Route path="bank/accounts-category/edit/:id" element={<AccountsCategoryEdit />} />
            <Route path="bank/accounts-head" element={<AccountsHeadList />} />
            <Route path="bank/accounts-head/add" element={<AccountsHeadAdd />} />
            <Route path="bank/accounts-head/edit/:id" element={<AccountsHeadEdit />} />
            <Route path="bank/budget-details" element={<BudgetDetailsList />} />
            <Route path="bank/budget-details/add" element={<BudgetDetailsAdd />} />
            <Route path="bank/budget-details/edit/:id" element={<BudgetDetailsEdit />} />

            <Route path="customer/customer-category" element={<CustomerCategoryList />} />
            <Route path="customer/customer-category/add" element={<CustomerCategoryAdd />} />
            <Route path="customer/customer-category/edit/:id" element={<CustomerCategoryEdit />} />

            <Route path="customer/customer" element={<CustomerList />} />
            <Route path="customer/customer/add" element={<CustomerAdd />} />
            <Route path="customer/customer/edit/:id" element={<CustomerEdit />} />

            <Route path="customer/customer-sub-category" element={<CustomerSubList />} />
            <Route path="customer/customer-sub-category/add" element={<CustomerSubAdd />} />
            <Route path="customer/customer-sub-category/edit/:id" element={<CustomerSubEdit />} />

            <Route path="customer/customer-group" element={<CustomerGroupList />} />
            <Route path="customer/customer-group/add" element={<CustomerGroupAdd />} />
            <Route path="customer/customer-group/edit/:id" element={<CustomerGroupEdit />} />

            <Route path="customer/customer-grading" element={<CustomerGradingList />} />
            <Route path="customer/customer-grading/add" element={<CustomerGradingAdd />} />
            <Route path="customer/customer-grading/edit/:id" element={<CustomerGradingEdit />} />

            <Route path="items/brand" element={<BrandList />} />
            <Route path="items/brand/add" element={<BrandAdd />} />
            <Route path="items/brand/edit/:id" element={<BrandEdit />} />

            <Route path="items/product-group" element={<ProductGroupList />} />
            <Route path="items/product-group/add" element={<ProductGroupAdd />} />
            <Route path="items/product-group/edit/:id" element={<ProductGroupEdit />} />

            <Route path="items/product-category" element={<ProductCategoryList />} />
            <Route path="items/product-category/add" element={<ProductCategoryAdd />} />
            <Route path="items/product-category/edit/:id" element={<ProductCategoryEdit />} />

            <Route path="items/product-sub-category" element={<ProductSubList />} />
            <Route path="items/product-sub-category/add" element={<ProductSubAdd />} />
            <Route path="items/product-sub-category/edit/:id" element={<ProductSubEdit />} />

            <Route path="items/product-model" element={<ProductModelList />} />
            <Route path="items/product-model/add" element={<ProductModelAdd />} />
            <Route path="items/product-model/edit/:id" element={<ProductModelEdit />} />

            <Route path="items/product" element={<ProductList />} />
            <Route path="items/product/add" element={<ProductAdd />} />
            <Route path="items/product/edit/:id" element={<ProductEdit />} />

            <Route path="items/inspection-question" element={<InspectionQuestionsList />} />
            <Route path="items/inspection-question/add" element={<InspectionQuestionsAdd />} />
            <Route path="items/inspection-question/edit/:id" element={<InspectionQuestionsEdit />} />

            <Route path="items/product-inspection-mapping" element={<ProductInspectionList />} />
            <Route path="items/product-inspection-mapping/add" element={<ProductInspectionAdd />} />
            <Route path="items/product-inspection-mapping/edit/:id" element={<ProductInspectionEdit />} />

            <Route path="vendor/vendor" element={<VendorList />} />
            <Route path="vendor/vendor/add" element={<VendorAdd />} />
            <Route path="vendor/vendor/edit/:id" element={<VendorEdit />} />

            <Route path="vendor/vendor-product-mapping" element={<VendorMappingList />} />
            <Route path="vendor/vendor-product-mapping/add" element={<VendorMappingAdd />} />
            <Route path="vendor/vendor-product-mapping/edit/:id" element={<VendorMappingEdit />} />

            <Route path="vendor/vendor-category" element={<VendorCategoryList />} />
            <Route path="vendor/vendor-category/add" element={<VendorCategoryAdd />} />
            <Route path="vendor/vendor-category/edit/:id" element={<VendorCategoryEdit />} />

            <Route path="vendor/vendor-sub-category" element={<VendorSubList />} />
            <Route path="vendor/vendor-sub-category/add" element={<VendorSubAdd />} />
            <Route path="vendor/vendor-sub-category/edit/:id" element={<VendorSubEdit />} />

            <Route path="vendor/vendor-group" element={<VendorGroupList />} />
            <Route path="vendor/vendor-group/add" element={<VendorGroupAdd />} />
            <Route path="vendor/vendor-group/edit/:id" element={<VendorGroupEdit />} />

            <Route path="items/stock-location" element={<StockLocationList />} />
            <Route path="items/stock-location/add" element={<StockLocationAdd />} />
            <Route path="items/stock-location/edit/:id" element={<StockLocationEdit />} />

            <Route path="items/unit" element={<UnitList />} />
            <Route path="items/unit/add" element={<UnitAdd />} />
            <Route path="items/unit/edit/:id" element={<UnitEdit />} />

            <Route path="feedback/feedback-parameter" element={<FeedbackParameterList />} />
            <Route path="feedback/feedback-parameter/add" element={<FeedbackParameterAdd />} />
            <Route path="feedback/feedback-parameter/edit/:id" element={<FeedbackParameterEdit />} />

            <Route path="reminder/email" element={<EmailList />} />
            <Route path="reminder/email/add" element={<EmailAdd />} />
            <Route path="reminder/email/edit/:id" element={<EmailEdit />} />

            <Route path="reminder/sms" element={<SmsList />} />
            <Route path="reminder/sms/add" element={<SmsAdd />} />
            <Route path="reminder/sms/edit/:id" element={<SmsEdit />} />

            <Route path="bulksms/bulksms" element={<BulkSmsList />} />
            <Route path="bulksms/bulksms/add" element={<BulkSmsAdd />} />
            <Route path="bulksms/bulksms/edit/:id" element={<BulkSmsEdit />} />

            <Route path="transporter/transporter-mode" element={<TransporterModeList />} />
            <Route path="transporter/transporter-mode/add" element={<TransporterModeAdd />} />
            <Route path="transporter/transporter-mode/edit/:id" element={<TransporterModeEdit />} />

            <Route path="transporter/transporter-details" element={<TransporterDetailsList />} />
            <Route path="transporter/transporter-details/add" element={<TransporterDetailsAdd />} />
            <Route path="transporter/transporter-details/edit/:id" element={<TransporterDetailsEdit />} />
        </Routes>
    );
}
// Force Vite HMR reload
