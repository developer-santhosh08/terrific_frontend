﻿import { useTableControls } from '../../../../hooks/useTableControls';
import { useLoader } from '../../../../context/LoaderContext';
import Pagination from '../../../../components/Pagination';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { PencilSimpleIcon, PlusIcon, TrashIcon } from '@phosphor-icons/react';
import TableSortIcon from '../../../../components/TableSortIcon';
import DeletePopup from '../../../../components/Popup/DeletePopup.jsx';

const ChequeBookList = () => {
    const { setLoading } = useLoader();

    const navigate = useNavigate();
    const [showDeletePopup, setShowDeletePopup] = useState(false);
    const [pendingDeleteId, setPendingDeleteId] = useState(null);
    const [data, setData] = useState([]);

    const fetchChequeBooks = async () => {
        try {
            const token = sessionStorage.getItem('erp_token');
            const [chequeRes, bankRes, accRes] = await Promise.all([
                fetch(`${import.meta.env.VITE_API_BASE_URL}/api/master/cheque-book`, { headers: { 'Accept': 'application/json', 'Authorization': `Bearer ${token}` } }),
                fetch(`${import.meta.env.VITE_API_BASE_URL}/api/master/bank`, { headers: { 'Accept': 'application/json', 'Authorization': `Bearer ${token}` } }),
                fetch(`${import.meta.env.VITE_API_BASE_URL}/api/master/account-detail`, { headers: { 'Accept': 'application/json', 'Authorization': `Bearer ${token}` } })
            ]);
            
            const result = await chequeRes.json();
            const bankJson = await bankRes.json();
            const accJson = await accRes.json();

            let bankMap = {};
            if (bankJson.status && bankJson.data) {
                bankMap = bankJson.data.reduce((acc, b) => { acc[b.id] = b.name; return acc; }, {});
            }
            let accMap = {};
            if (accJson.status && accJson.data) {
                accMap = accJson.data.reduce((acc, a) => { acc[a.id] = a.account_number; return acc; }, {});
            }

            if (result.status && result.data) {
                const formattedData = result.data.map(item => ({
                    id: item.id,
                    bank: bankMap[item.bank_id] || item.bank_id || '',
                    account: accMap[item.bank_account_details_id] || item.bank_account_details_id || '',
                    noOfLeaf: item.number_of_leaf || '',
                    leafStartNumber: item.starting_number || '',
                    leafEndNumber: item.ending_number || '',
                    status: (item.status === 1 || item.status === '1' || item.status === 'Active') ? 'Active' : 'Inactive'
                })).sort((a, b) => b.id - a.id);
                setData(formattedData);
            }
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    useEffect(() => {
        fetchChequeBooks();
    }, []);

    const handleDelete = (id) => {
        setPendingDeleteId(id);
        setShowDeletePopup(true);
    };

    const handleConfirmDelete = async () => {
        try {
            const token = sessionStorage.getItem('erp_token');
            await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/master/cheque-book/${pendingDeleteId}`, {
                method: 'DELETE',
                headers: {
                    'Accept': 'application/json',
                    'Authorization': `Bearer ${token}`
                }
            });
            setData(prev => prev.filter(d => d.id !== pendingDeleteId));
        } catch {
            // silently ignore
        } finally {
            setShowDeletePopup(false);
            setPendingDeleteId(null);
        }
    };

    const {
        sortConfig,
        handleSort,
        searchQuery,
        setSearchQuery,
        entriesPerPage,
        setEntriesPerPage,
        currentPage,
        setCurrentPage,
        totalPages,
        startIndex,
        endIndex,
        totalEntries,
        paginatedData: sortedData
    } = useTableControls(data);

    return (
                <section className="content">
            <div className="container-fluid">
                <div className="card">
                    <div className="card-header with-border d-flex justify-content-between align-items-center">
                        <h3 className="card-title"> Cheque Book</h3>
                        <div className="d-flex align-items-center tw-gap-4">
                            <button
                                className="btn-create d-flex align-items-center tw-gap-1"
                                onClick={() => navigate('/power-master/bank/cheque-book/add')}
                            >
                                <PlusIcon weight="bold" className="tw-w-4 text-white" />
                                <span className="text-white">Create New</span>
                            </button>
                        </div>
                    </div>
                    <div className="card-body">
                        <div className="list-top-bar">
                            <div className="d-flex align-items-center">
                                <span className="me-2">Show</span>
                                <select 
                                    className="form-select form-select-sm tw-border-slate-300 me-2" 
                                    style={{ width: '70px' }}
                                    value={entriesPerPage}
                                    onChange={(e) => setEntriesPerPage(Number(e.target.value))}
                                >
                                    <option value="10">10</option>
                                    <option value="25">25</option>
                                    <option value="50">50</option>
                                    <option value="100">100</option>
                                </select>
                                <span>entries</span>
                            </div>
                            <div className="d-flex align-items-center">
                                <span className="me-2">Search:</span>
                                <input 
                                    type="text" 
                                    className="form-control form-control-sm tw-border-slate-300" 
                                    style={{ width: 'auto' }} 
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                />
                            </div>
                        </div>

                        <div className="table-responsive">
                            <table className="table table-bordered table-striped no-margin">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th onClick={() => handleSort('bank')} className="tw-cursor-pointer tw-select-none">Bank Name <TableSortIcon direction={sortConfig.key === 'bank' ? sortConfig.direction : null} /></th>
                                        <th onClick={() => handleSort('account')} className="tw-cursor-pointer tw-select-none">Account Name <TableSortIcon direction={sortConfig.key === 'account' ? sortConfig.direction : null} /></th>
                                        <th onClick={() => handleSort('noOfLeaf')} className="tw-cursor-pointer tw-select-none">No Of Leaf <TableSortIcon direction={sortConfig.key === 'noOfLeaf' ? sortConfig.direction : null} /></th>
                                        <th onClick={() => handleSort('leafStartNumber')} className="tw-cursor-pointer tw-select-none">Leaf Start Number <TableSortIcon direction={sortConfig.key === 'leafStartNumber' ? sortConfig.direction : null} /></th>
                                        <th onClick={() => handleSort('leafEndNumber')} className="tw-cursor-pointer tw-select-none">Leaf End Number <TableSortIcon direction={sortConfig.key === 'leafEndNumber' ? sortConfig.direction : null} /></th>
                                        <th onClick={() => handleSort('status')} className="tw-cursor-pointer tw-select-none">Status <TableSortIcon direction={sortConfig.key === 'status' ? sortConfig.direction : null} /></th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {sortedData.map((e, index) => (
                                        <tr key={index}>
                                            <td className="align-middle">{startIndex + index}</td>
                                            <td className="align-middle">{e.bank}</td>
                                            <td className="align-middle">{e.account}</td>
                                            <td className="align-middle">{e.noOfLeaf}</td>
                                            <td className="align-middle">{e.leafStartNumber}</td>
                                            <td className="align-middle">{e.leafEndNumber}</td>
                                            <td className="align-middle">
                                                <span className={`badge ${e.status === 'Active' ? 'bg-success' : 'bg-danger'}`}>
                                                    {e.status}
                                                </span>
                                            </td>
                                            <td className="align-middle">
                                                <div className="tw-flex tw-gap-2">
                                                    <button type="button" className="list-action-btn btn-edit" onClick={() => navigate(`/power-master/bank/cheque-book/edit/${e.id}`)}>
                                                        <PencilSimpleIcon weight="duotone" className="tw-w-4" />
                                                    </button>
                                                    <button
                                                        type="button"
                                                        className="list-action-btn btn-delete"
                                                        onClick={() => handleDelete(e.id)}
                                                    >
                                                        <TrashIcon weight="duotone" className="tw-w-4" />
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                    {sortedData.length === 0 && (
                                        <tr>
                                            <td colSpan="8" className="text-center tw-py-4">No data available in table</td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                        <div className="tw-flex tw-justify-between tw-items-center tw-mt-4">
                            <div className="tw-text-gray-600 tw-text-sm">
                                Showing {totalEntries === 0 ? 0 : startIndex} to {endIndex} of {totalEntries} entries
                            </div>
                            <Pagination 
                                currentPage={currentPage} 
                                totalPages={totalPages} 
                                onPageChange={setCurrentPage} 
                            />
                        </div>
                    </div>
                </div>
            </div>
            <DeletePopup
                isOpen={showDeletePopup}
                onClose={() => { setShowDeletePopup(false); setPendingDeleteId(null); }}
                onConfirm={handleConfirmDelete}
            />
        </section>
    );
};

export default ChequeBookList;
