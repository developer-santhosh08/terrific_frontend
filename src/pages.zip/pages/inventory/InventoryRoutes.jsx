import { Routes, Route } from 'react-router-dom';
import StockDetails from './StockDetails';
import DirectPurchaseOrderList from './DirectGrn/DirectPurchaseOrderList';
import DirectPurchaseOrderAdd from './DirectGrn/DirectPurchaseOrderAdd';
import DirectPurchaseOrderEdit from './DirectGrn/DirectPurchaseOrderEdit';
import DirectPurchaseOrderPrint from './DirectGrn/DirectPurchaseOrderPrint';
import GrnList from './GrnInspection/GrnList';
import GrnAdd  from './GrnInspection/GrnAdd';
import GrnEdit from './GrnInspection/GrnEdit';
import PurchaseOrderList from './PurchaseOrder/PurchaseOrderList';
import PurchaseOrderAdd from './PurchaseOrder/PurchaseOrderAdd';
import PurchaseOrderEdit from './PurchaseOrder/PurchaseOrderEdit';
import PurchaseOrderPrint from './PurchaseOrder/PurchaseOrderPrint';
import SuggesdOrderList from './SuggestPurchaseOrder/SuggesdOrderList';
import FutureList from './FutureGrn/FutureList';
import FutureAdd from './FutureGrn/FutureAdd';
import AdvancedPaymentList from './AdvancedPayments/AdvancedPaymentList';
import AdvancePaymentEdit from './AdvancedPayments/AdvancePaymentEdit';
import AdvancedPaymentPrint from './AdvancedPayments/AdvancedPaymentPrint';
import AdvanceReceiptEdit from './AdvancedPayments/AdvanceReceiptEdit';
import StockTransferList from './StockTransfer/StockTransferList';
import FurtherReciptList from './FurtherRecipt/FurtherReciptList';
import ReciptEdit from './FurtherRecipt/ReciptEdit';
import ReciptUpdate from './FurtherRecipt/ReciptUpdate';

export default function InventoryRoutes() {
    return (
        <Routes>
            <Route path="" element={<StockDetails />} />
            <Route path="stock-details" element={<StockDetails />} />
            <Route path="direct-grn" element={<DirectPurchaseOrderList />} />
            <Route path="direct-grn/add" element={<DirectPurchaseOrderAdd />} />
            <Route path="direct-grn/edit/:id" element={<DirectPurchaseOrderEdit />} />
            <Route path="direct-grn/print/:id" element={<DirectPurchaseOrderPrint />} />
            <Route path="grn-inspection" element={<GrnList />} />
            <Route path="grn-inspection/add" element={<GrnAdd />} />
            <Route path="grn-inspection/edit/:id" element={<GrnEdit />} />
            <Route path="grn/add" element={<DirectPurchaseOrderAdd />} />
            <Route path="grn/edit/:id" element={<DirectPurchaseOrderEdit />} />
            <Route path="purchase-order" element={<PurchaseOrderList />} />
            <Route path="purchase-order/add" element={<PurchaseOrderAdd />} />
            <Route path="purchase-order/edit/:id" element={<PurchaseOrderEdit />} />
            <Route path="purchase-order/print/:id" element={<PurchaseOrderPrint />} />
            <Route path="suggested-order" element={<SuggesdOrderList />} />
            <Route path="future-inspection" element={<FutureList />} />
            <Route path="future-inspection/add" element={<FutureAdd />} />
            <Route path="future-inspection/edit/:id" element={<FutureAdd />} />
            <Route path="advanced-payments" element={<AdvancedPaymentList />} />
            <Route path="advanced-payments/edit/:id" element={<AdvancePaymentEdit />} />
            <Route path="advanced-payments/print/:id" element={<AdvancedPaymentPrint />} />
            <Route path="advanced-payments/receipt-edit/:id" element={<AdvanceReceiptEdit />} />
            <Route path="stock-transfer" element={<StockTransferList />} />
            <Route path="further-receipt" element={<FurtherReciptList />} />
            <Route path="further-receipt/edit/:id" element={<ReciptEdit />} />
            <Route path="further-receipt/update/:id" element={<ReciptUpdate />} />
        </Routes>
    );
}
