import { Routes, Route } from 'react-router-dom';
import ReportingList from './ReportingList';
import ReportingAdd from './ReportingAdd';
import ReportingEdit from './ReportingEdit';

export default function ReportingRoutes() {
    return (
        <Routes>
            <Route path="" element={<ReportingList />} />
            <Route path="add" element={<ReportingAdd />} />
            <Route path="edit/:id" element={<ReportingEdit />} />
        </Routes>
    );
}
