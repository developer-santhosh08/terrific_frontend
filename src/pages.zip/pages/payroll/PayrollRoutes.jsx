import { Routes, Route } from 'react-router-dom';
import PayrollEntry  from './PayrollEntry';
import PayrollList   from './PayrollList';
import PayrollReport from './PayrollReport';
import SalaryStructureList from './SalaryStructureList';

export default function PayrollRoutes() {
    return (
        <Routes>
            <Route path=""       element={<PayrollEntry />}  />
            <Route path="salary" element={<PayrollEntry />}  />
            <Route path="list"   element={<PayrollList />}   />
            <Route path="report" element={<PayrollReport />} />
            <Route path="structures" element={<SalaryStructureList />} />
        </Routes>
    );
}
