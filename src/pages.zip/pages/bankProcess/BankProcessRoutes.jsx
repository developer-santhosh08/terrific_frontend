import { Routes, Route } from 'react-router-dom';
import BankProcessList from './BankProcessList';
import BankProcessAdd from './BankProcessAdd';
import BankProcessEdit from './BankProcessEdit';
import CheckList from './checkTransaction/CheckList';
import PaymentVoucherList from './paymentVoucher/PaymentVoucherList';
import PaymentVoucherAdd from './paymentVoucher/PaymentVoucherAdd';
import PaymentVoucherEdit from './paymentVoucher/PaymentVoucherEdit';
import ReconciliationList from './reconciliation/ReconciliationList';
import CustomerRecipt from './customerOpenaningRecipt/CustomerRecipt';
import DebitNote from './debitNote/DebitNote';
import DailyWise from './dayWiseReport/DailyWise';
import Receipt from './receipt/Recipt';

export default function BankProcessRoutes() {
    return (
        <Routes>
            <Route path="" element={<BankProcessList />} />
            <Route path="add" element={<BankProcessAdd />} />
            <Route path="edit/:id" element={<BankProcessEdit />} />
            <Route path="cheque-transaction" element={<CheckList />} />
            <Route path="payment-voucher" element={<PaymentVoucherList />} />
            <Route path="payment-voucher/add" element={<PaymentVoucherAdd />} />
            <Route path="payment-voucher/edit/:id" element={<PaymentVoucherEdit />} />
            <Route path="reconciliation" element={<ReconciliationList />} />
            <Route path="customer-opening-receipt" element={<CustomerRecipt />} />
            <Route path="debit-note" element={<DebitNote />} />
            <Route path="daywise-report" element={<DailyWise />} />
            <Route path="receipt" element={<Receipt />} />
        </Routes>
    );
}
