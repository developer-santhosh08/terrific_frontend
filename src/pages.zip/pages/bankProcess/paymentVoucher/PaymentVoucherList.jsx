import { useTableControls } from '../../../hooks/useTableControls';
import { useState, useMemo, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { PrinterIcon, PencilSimpleIcon, TrashIcon } from '@phosphor-icons/react';
import TableSortIcon from '../../../components/TableSortIcon';
import { useSortableData } from '../../../hooks/useSortableData';

const PaymentVoucherList = () => {
	const navigate = useNavigate();

	const vouchers = [
		{ id: 1, date: '2026-06-01', voucherType: 'Payment', payTo: 'ABC Suppliers', accountName: 'Bank - HDFC', amount: 12500, status: 'Active' },
		{ id: 2, date: '2026-05-28', voucherType: 'Receipt', payTo: 'XYZ Services', accountName: 'Bank - SBI', amount: 4300, status: 'Inactive' }
	];

	const { items: sortedVouchers, requestSort, getSortDirection } = useSortableData(vouchers);

	const [searchText, setSearchText] = useState('');
	const [pageSize, setPageSize] = useState(10);
	const [currentPage, setCurrentPage] = useState(1);

	const filtered = useMemo(() => {
		const q = (searchText || '').toString().trim().toLowerCase();
		if (!q) return sortedVouchers;
		return sortedVouchers.filter(v => (
			(v.date || '').toString().toLowerCase().includes(q) ||
			(v.voucherType || '').toString().toLowerCase().includes(q) ||
			(v.payTo || '').toString().toLowerCase().includes(q) ||
			(v.accountName || '').toString().toLowerCase().includes(q) ||
			(v.amount || '').toString().toLowerCase().includes(q) ||
			(v.status || '').toString().toLowerCase().includes(q)
		));
	}, [sortedVouchers, searchText]);

	const total = filtered.length;
	const totalPages = Math.max(1, Math.ceil(total / pageSize));

	useEffect(() => { if (currentPage > totalPages) setCurrentPage(totalPages); }, [totalPages, currentPage]);
	useEffect(() => { setCurrentPage(1); }, [pageSize, searchText]);

	const startIndex = (currentPage - 1) * pageSize;
	const paginated = filtered.slice(startIndex, startIndex + pageSize);

	const openPrint = (v) => {
		const html = `<html><body><h3>Payment Voucher</h3><div>Date: ${v.date}</div><div>Pay To: ${v.payTo}</div><div>Amount: ${v.amount}</div><script>setTimeout(()=>window.print(),200)</script></body></html>`;
		const w = window.open('', '_blank'); if (!w) return alert('Popup blocked'); w.document.open(); w.document.write(html); w.document.close();
	};

	return (
		<section className="content">
			<div className="container-fluid">
				<div className="card">
					<div className="card-header with-border d-flex justify-content-between align-items-center">
						<h3 className="card-title">Payment Voucher List</h3>
						<button className="btn-create" onClick={() => navigate('/bank-process/payment-voucher/add')}>Add Voucher</button>
					</div>
					<div className="card-body">
						<div className="list-top-bar">
							<div className="tw-flex tw-items-center tw-gap-2">
								<span>Show</span>
								<select className="form-select form-select-sm tw-w-20 tw-inline-block" value={pageSize} onChange={e => setPageSize(Number(e.target.value))}>
									<option value="10">10</option>
									<option value="25">25</option>
									<option value="50">50</option>
									<option value="100">100</option>
								</select>
								<span>entries</span>
							</div>
							<div className="tw-flex tw-items-center tw-gap-2">
								<span>Search:</span>
								<input type="text" className="form-control form-control-sm tw-w-48 tw-inline-block" value={searchText} onChange={e => setSearchText(e.target.value)} />
							</div>
						</div>

						<div className="table-responsive">
							<table className="table table-bordered table-striped no-margin">
								<thead>
									<tr>
										<th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50" onClick={() => requestSort('id')}><div className="tw-flex tw-justify-between tw-items-center"># <TableSortIcon direction={getSortDirection('id')} /></div></th>
										<th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50" onClick={() => requestSort('date')}><div className="tw-flex tw-justify-between tw-items-center">Date <TableSortIcon direction={getSortDirection('date')} /></div></th>
										<th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50" onClick={() => requestSort('voucherType')}><div className="tw-flex tw-justify-between tw-items-center">Voucher Type <TableSortIcon direction={getSortDirection('voucherType')} /></div></th>
										<th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50" onClick={() => requestSort('payTo')}><div className="tw-flex tw-justify-between tw-items-center">Pay To <TableSortIcon direction={getSortDirection('payTo')} /></div></th>
										<th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50" onClick={() => requestSort('accountName')}><div className="tw-flex tw-justify-between tw-items-center">Account Name <TableSortIcon direction={getSortDirection('accountName')} /></div></th>
										<th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50" onClick={() => requestSort('amount')}><div className="tw-flex tw-justify-between tw-items-center">Amount <TableSortIcon direction={getSortDirection('amount')} /></div></th>
										<th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50" onClick={() => requestSort('status')}><div className="tw-flex tw-justify-between tw-items-center">Status <TableSortIcon direction={getSortDirection('status')} /></div></th>
										<th className="tw-align-middle tw-cursor-pointer hover:tw-bg-slate-50"><div className="tw-flex tw-justify-between tw-items-center">Action <TableSortIcon /></div></th>
									</tr>
								</thead>
								<tbody>
									{paginated.map((v, idx) => (
										<tr key={v.id}>
											<td>{startIndex + idx + 1}</td>
											<td>{v.date}</td>
											<td>{v.voucherType}</td>
											<td>{v.payTo}</td>
											<td>{v.accountName}</td>
											<td>{v.amount}</td>
											<td>{v.status === 'Active' ? <span className="tw-inline-block tw-px-2 tw-py-1 tw-rounded tw-text-xs tw-font-medium tw-bg-emerald-500 tw-text-white">Active</span> : <span className="tw-inline-block tw-px-2 tw-py-1 tw-rounded tw-text-xs tw-font-medium tw-bg-red-400 tw-text-white">Inactive</span>}</td>
											<td>
												<div className="tw-flex tw-gap-2">
													<button type="button" className="list-action-btn btn-print" title="Print" onClick={() => openPrint(v)}>
														<PrinterIcon weight="duotone" className="tw-w-4" />
													</button>
													<button type="button" className="list-action-btn btn-edit" title="Edit" onClick={() => navigate(`/bank-process/payment-voucher/edit/${v.id}`)}>
														<PencilSimpleIcon weight="duotone" className="tw-w-4" />
													</button>
													<button type="button" className="list-action-btn btn-delete" title="Delete" onClick={() => console.log('delete', v.id)}>
														<TrashIcon weight="duotone" className="tw-w-4" />
													</button>
												</div>
											</td>
										</tr>
									))}
									{paginated.length === 0 && (
										<tr>
											<td colSpan="8" className="tw-text-center tw-text-slate-400 tw-py-8">No records found</td>
										</tr>
									)}
								</tbody>
							</table>
						</div>

						<div className="tw-flex tw-justify-between tw-items-center tw-mt-4">
							<div className="tw-text-gray-600 tw-text-sm">
								Showing {total === 0 ? 0 : startIndex + 1} to {Math.min(startIndex + pageSize, total)} of {total} entries
							</div>
							<div className="tw-flex tw-items-center">
								<button className="btn btn-sm btn-outline-secondary tw-border-gray-300 tw-rounded-r-none tw-bg-white hover:tw-bg-gray-50 tw-text-gray-600" onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1}>Previous</button>
								<button className="btn btn-sm tw-bg-blue-500 tw-text-white tw-border-blue-500 tw-rounded-none tw-px-3">{currentPage}</button>
								<button className="btn btn-sm btn-outline-secondary tw-border-gray-300 tw-rounded-l-none tw-bg-white hover:tw-bg-gray-50 tw-text-gray-600" onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages}>Next</button>
							</div>
						</div>

					</div>
				</div>
			</div>
		</section>
	);
};

export default PaymentVoucherList;
