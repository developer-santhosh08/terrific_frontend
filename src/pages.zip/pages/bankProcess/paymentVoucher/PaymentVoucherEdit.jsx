import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import Select from 'react-select';

const rsStyles = {
    control: (provided) => ({ ...provided, background: '#fff', minHeight: '36px' }),
    menu: (provided) => ({ ...provided, zIndex: 9999 })
};

const PaymentVoucherEdit = () => {
    const navigate = useNavigate();
    const { id } = useParams();

    const voucherTypeOptions = [
        { value: 'general', label: 'General Voucher' },
        { value: 'salary', label: 'Salary Voucher' }
    ];
    const budgetOptions = [
        { value: 'eng', label: 'Eng Expenses' },
        { value: 'ops', label: 'Operations' }
    ];
    const employeeOptions = [
        { value: 'gokul', label: 'Gokul' },
        { value: 'arun', label: 'Arun' }
    ];
    const yesNo = [ { value: 'yes', label: 'Yes' }, { value: 'no', label: 'No' } ];
    const jobcardOptions = [ { value: 'JC-1001', label: 'JC-1001' }, { value: 'JC-1002', label: 'JC-1002' } ];
    const paymentModeOptions = [ { value: 'cash', label: 'Cash' }, { value: 'cheque', label: 'Cheque' }, { value: 'rtgs', label: 'RTGS' }, { value: 'gpay', label: 'G-pay' } ];
    const accountHolderOptions = [
        { value: 'hdfc', label: 'HDFC - 1234' },
        { value: 'sbi', label: 'SBI - 5678' }
    ];

    const [date, setDate] = useState('2026-06-06');
    const [voucherType, setVoucherType] = useState(voucherTypeOptions[0]);
    const [budgetName, setBudgetName] = useState(budgetOptions[0]);
    const [employee, setEmployee] = useState(employeeOptions[0]);
    const [ifJobcard, setIfJobcard] = useState(yesNo[1]);
    const [jobcardChecked, setJobcardChecked] = useState(false);
    const [selectedJobcard, setSelectedJobcard] = useState(null);
    const [transactionType, setTransactionType] = useState('Debit');
    const txnOptions = [ { value: 'Debit', label: 'Debit' }, { value: 'Credit', label: 'Credit' } ];
    const [paymentMode, setPaymentMode] = useState(paymentModeOptions[0]);
    const [accountHolder, setAccountHolder] = useState(accountHolderOptions[0]);
    const [balanceBudget] = useState('15000.00');
    const [amount, setAmount] = useState('5000');
    const [suspense, setSuspense] = useState(yesNo[0]);
    const [remark, setRemark] = useState('');

    useEffect(() => {
        // load details by id - placeholder
    }, [id]);

    const handleSubmit = (e) => {
        e.preventDefault();
        const payload = { id, date, voucherType, budgetName, employee, ifJobcard, jobcardChecked, selectedJobcard, transactionType, paymentMode, accountHolder, amount, suspense, remark };
        console.log('Update Payment Voucher', payload);
        navigate('/bank-process/payment-voucher');
    };

    return (
        <section className="content">
            <div className="container-fluid">
                <div className="card">
                    <div className="card-header with-border d-flex justify-content-between align-items-center">
                        <h3 className="card-title">Edit Payment Voucher</h3>
                        <button className="btn-header-back" onClick={() => navigate('/bank-process/payment-voucher')}> Back</button>
                    </div>
                    <div className="card-body">
                        <form onSubmit={handleSubmit}>
                            <div className="row">
                                <div className="col-md-3 form-group">
                                    <label>Date</label>
                                    <input type="date" className="form-control" value={date} onChange={e => setDate(e.target.value)} />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>Payment Voucher Type <span className="text-danger">*</span></label>
                                    <Select options={voucherTypeOptions} styles={rsStyles} value={voucherType} onChange={setVoucherType} placeholder="Select Voucher Type" />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>Budget Name <span className="text-danger">*</span></label>
                                    <Select options={budgetOptions} styles={rsStyles} value={budgetName} onChange={setBudgetName} placeholder="Select Budget" />
                                </div>
                                 <div className="col-md-3 form-group">
                                    <label>Employee Name <span className="text-danger">*</span></label>
                                    <Select options={employeeOptions} styles={rsStyles} value={employee} onChange={setEmployee} placeholder="Select Employee" />
                                </div>
                            </div>

                            <div className="row">                                                            
                                <div className="col-md-3 form-group">
                                    <label>Transaction Type</label>
                                    <Select options={txnOptions} styles={rsStyles} value={txnOptions.find(o=>o.value===transactionType)} onChange={opt => setTransactionType(opt ? opt.value : '')} placeholder="Select" />
                                </div>
                                 <div className="col-md-3 form-group">
                                    <label>Payment Mode</label>
                                    <Select options={paymentModeOptions} styles={rsStyles} value={paymentMode} onChange={setPaymentMode} placeholder="Select Mode" />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>Account Holder Name <span className="text-danger">*</span></label>
                                    <Select options={accountHolderOptions} styles={rsStyles} value={accountHolder} onChange={setAccountHolder} placeholder="Choose Account Holder" />
                                </div>
                                 <div className="col-md-3 form-group">
                                    <label>Balance Budget Amount</label>
                                    <input type="text"  className="form-control" value={balanceBudget} readOnly />
                                </div>
                            </div>

                            <div className="row">    
                                <div className="col-md-3 form-group">
                                    <label>Amount <span className="text-danger">*</span></label>
                                    <input type="number" className="form-control" value={amount} onChange={e => setAmount(e.target.value)} />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>Suspense</label>
                                    <Select options={yesNo} styles={rsStyles} value={suspense} onChange={setSuspense} placeholder="Select" />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>Remark</label>
                                    <input type="text" className="form-control" value={remark} onChange={e => setRemark(e.target.value)} />
                                </div>
                            </div>

                            <div className="tw-mt-3">
                                <div className="form-check">
                                    <input className="form-check-input" type="checkbox" id="ifJobcardEdit" checked={jobcardChecked} onChange={e => {
                                        const checked = e.target.checked;
                                        setJobcardChecked(checked);
                                        setIfJobcard(checked ? yesNo[0] : yesNo[1]);
                                        if (!checked) {
                                            setSelectedJobcard(null);
                                        }
                                    }} />
                                    <label className="form-check-label" htmlFor="ifJobcardEdit">If Jobcard</label>
                                </div>
                                {jobcardChecked && (
                                    <div className="tw-mt-2" style={{ maxWidth: 360 }}>
                                        <label>Jobcard Number</label>
                                        <Select options={jobcardOptions} styles={rsStyles} value={selectedJobcard} onChange={setSelectedJobcard} placeholder="Select Jobcard" />
                                    </div>
                                )}
                            </div>

                            <div className="form-actions mt-3 d-flex justify-content-between">
                                <button type="button" className="btn-cancel" onClick={() => navigate('/bank-process/payment-voucher')}>Cancel</button>
                                <button type="submit" className="btn-save">Update Voucher</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default PaymentVoucherEdit;
