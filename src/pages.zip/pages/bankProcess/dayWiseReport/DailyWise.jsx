import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Select from 'react-select';

const DailyWise = () => {
    const navigate = useNavigate();
    const voucherOptions = [
        { value: 'General Voucher', label: 'General Voucher' },
        { value: 'Payment Voucher', label: 'Payment Voucher' },
        { value: 'Receipt Voucher', label: 'Receipt Voucher' },
        { value: 'Contra Voucher', label: 'Contra Voucher' },
        { value: 'Journal Voucher', label: 'Journal Voucher' },
    ];

    const [voucherType, setVoucherType] = useState(voucherOptions[0]);
    const [fromDate, setFromDate] = useState('');
    const [toDate, setToDate] = useState('');

    const handleCancel = () => {
        setVoucherType(voucherOptions[0]);
        setFromDate('');
        setToDate('');
    };

    return (
        <section className="content">
            <div className="container-fluid">
                <div className="card">
                    <div className="card-header with-border d-flex justify-content-between align-items-center">
                        <h3 className="card-title">Daywise Expense Report</h3>
                        {/* <button className="btn-header-back" onClick={() => navigate('/bankProcess/daywise-report')}>Back</button> */}
                    </div>

                    <div className="card-body">
                        <form onSubmit={e => { e.preventDefault(); window.print(); }}>
                            <div className="row">
                                <div className="col-md-3 form-group">
                                    <label>Voucher Type</label>
                                    <Select
                                        options={voucherOptions}
                                        value={voucherType}
                                        onChange={opt => setVoucherType(opt)}
                                        styles={{ control: (p) => ({ ...p, background: '#fff', minHeight: '36px' }), menu: (p) => ({ ...p, zIndex: 9999 }) }}
                                    />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>From Date</label>
                                    <input
                                        type="date"
                                        className="form-control"
                                        value={fromDate}
                                        onChange={e => setFromDate(e.target.value)}
                                    />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>To Date</label>
                                    <input
                                        type="date"
                                        className="form-control"
                                        value={toDate}
                                        onChange={e => setToDate(e.target.value)}
                                    />
                                </div>
                            </div>

                            <div className="form-actions mt-3 d-flex justify-content-between">
                                <button type="button" className="btn-cancel" onClick={handleCancel}>Cancel</button>
                                <button type="submit" className="btn-save">Print</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default DailyWise;
